#!/usr/bin/env bash
# install.sh — instala a skill openstruct-issue em outro lugar (outra máquina, um repositório, o Codex).
#
# A instalação pessoal do Claude Code é a própria pasta ~/.claude/skills/openstruct-issue:
# se você está rodando este arquivo de lá, não há nada a instalar para o Claude Code.
#
# Nunca sobrescreve uma instalação existente sem confirmação. Ao sobrescrever, move a
# anterior para <destino>.bak.<data> em vez de apagar.

set -eu

usage() {
  cat <<'EOF'
Uso:
  ./install.sh user                         ~/.claude/skills e, se houver, o diretório de skills do Codex
  ./install.sh claude-project <raiz-repo>   <raiz>/.claude/skills (só Claude Code)
  ./install.sh project <raiz-repo>          fonte única em <raiz>/.agents/skills + link em .claude/skills

Opções:
  --copy             copia em vez de criar link simbólico (é o padrão no Windows)
  --codex-dir <dir>  diretório de skills de usuário do Codex (pula a detecção)
  --no-codex         não instala para o Codex (modo user)
  --yes              responde "sim" às confirmações (uso não interativo)
  --dry-run          só mostra o que faria

A cópia leva só os arquivos de uso (SKILL.md, references, scripts, examples, README.md);
evals/ e o histórico git ficam na origem.
EOF
}

NAME="openstruct-issue"
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
MODE="${1:-}"; [ $# -gt 0 ] && shift
ROOT=""
COPY=0; YES=0; DRY=0; NO_CODEX=0; CODEX_DIR=""

case "$MODE" in
  project|claude-project) ROOT="${1:-}"; [ $# -gt 0 ] && shift ;;
  user) ;;
  -h|--help|"") usage; exit 0 ;;
  *) echo "Modo desconhecido: $MODE" >&2; usage >&2; exit 2 ;;
esac
while [ $# -gt 0 ]; do
  case "$1" in
    --copy) COPY=1 ;;
    --yes) YES=1 ;;
    --dry-run) DRY=1 ;;
    --no-codex) NO_CODEX=1 ;;
    --codex-dir) CODEX_DIR="${2:?--codex-dir precisa de um caminho}"; shift ;;
    *) echo "Opção desconhecida: $1" >&2; exit 2 ;;
  esac
  shift
done

[ -f "$SRC/SKILL.md" ] || { echo "SKILL.md não encontrado em $SRC" >&2; exit 1; }

say() { printf '%s\n' "$*"; }
do_() { if [ "$DRY" = 1 ]; then say "  [dry-run] $*"; else "$@"; fi; }

# No Git Bash, `ln -s` copia em vez de criar link; então no Windows a instalação é sempre cópia.
case "$(uname -s 2>/dev/null)" in
  MINGW*|MSYS*|CYGWIN*) if [ "$COPY" = 0 ]; then COPY=1; say "(Windows: instalando por cópia, não por link)"; fi ;;
esac

confirm() {  # confirm "pergunta" → 0 = sim
  [ "$YES" = 1 ] && return 0
  if [ -r /dev/tty ] && [ -t 0 ]; then
    printf '%s [s/N] ' "$1" > /dev/tty
    read -r ans < /dev/tty || ans=""
    case "$ans" in s|S|sim|y|Y|yes) return 0 ;; esac
    return 1
  fi
  say "  (sem terminal interativo; use --yes para confirmar) → não" >&2
  return 1
}

realp() { (cd "$1" 2>/dev/null && pwd -P) || echo ""; }

copiar_uso() {  # origem, destino: só os arquivos de uso
  do_ mkdir -p "$2"
  for item in SKILL.md README.md references scripts examples; do
    [ -e "$1/$item" ] && do_ cp -R "$1/$item" "$2/"
  done
  return 0
}

# place <origem> <destino> [alvo-do-link]
place() {
  local from="$1" dest="$2" linkto="${3:-$1}" rd
  rd="$(realp "$dest")"
  if [ -n "$rd" ] && [ "$rd" = "$(realp "$from")" ]; then
    if [ -L "$dest" ]; then say "✓ já instalado (link): $dest"
    else say "✓ origem e destino são a mesma pasta, nada a fazer: $dest"; fi
    return 0
  fi
  if [ -e "$dest" ] || [ -L "$dest" ]; then
    say "! já existe: $dest"
    if ! confirm "  Substituir? (a versão atual vai para $dest.bak.*)"; then
      say "  mantido sem alterações"; return 0
    fi
    do_ mv "$dest" "$dest.bak.$(date +%Y%m%d%H%M%S)"
  fi
  do_ mkdir -p "$(dirname "$dest")"
  if [ "$COPY" = 1 ]; then
    copiar_uso "$from" "$dest"; say "✓ copiado: $dest"
  else
    do_ ln -s "$linkto" "$dest"; say "✓ link: $dest -> $linkto"
  fi
}

detect_codex_dir() {
  if [ -n "$CODEX_DIR" ]; then echo "$CODEX_DIR"; return; fi
  if [ -d "$HOME/.agents/skills" ]; then echo "$HOME/.agents/skills"; return; fi
  if [ -d "$HOME/.codex/skills" ]; then
    say "! Encontrado $HOME/.codex/skills, caminho antigo que a documentação do Codex lida em 2026-11-11 não lista (ela indica \$HOME/.agents/skills)." >&2
    if confirm "  Instalar em $HOME/.codex/skills mesmo assim?"; then echo "$HOME/.codex/skills"; return; fi
  fi
  if command -v codex >/dev/null 2>&1; then
    if confirm "Codex instalado. Criar $HOME/.agents/skills (caminho de usuário documentado)?"; then
      echo "$HOME/.agents/skills"; return
    fi
  fi
  echo ""
}

case "$MODE" in
  user)
    say "Claude Code (pessoal):"
    place "$SRC" "$HOME/.claude/skills/$NAME"
    if [ "$NO_CODEX" = 0 ]; then
      say "Codex (usuário): a skill não foi testada no Codex."
      cdir="$(detect_codex_dir)"
      if [ -n "$cdir" ]; then place "$SRC" "$cdir/$NAME"
      else say "  Codex não detectado ou não confirmado; nada feito. Use --codex-dir <dir> para indicar."; fi
    fi
    ;;
  project|claude-project)
    [ -n "$ROOT" ] || { echo "Informe a raiz do repositório." >&2; exit 2; }
    ROOT="$(realp "$ROOT")"; [ -n "$ROOT" ] || { echo "Raiz inválida." >&2; exit 1; }
    if [ "$MODE" = claude-project ]; then
      say "Claude Code (projeto):"
      place "$SRC" "$ROOT/.claude/skills/$NAME"
    else
      canon="$ROOT/.agents/skills/$NAME"
      say "Fonte única (Codex e Claude Code): $canon"
      saved=$COPY; COPY=1; place "$SRC" "$canon"; COPY=$saved
      say "Claude Code (projeto):"
      if [ "$COPY" = 1 ]; then place "$SRC" "$ROOT/.claude/skills/$NAME"
      else place "$canon" "$ROOT/.claude/skills/$NAME" "../../.agents/skills/$NAME"; fi   # link relativo: vale em qualquer clone
    fi
    ;;
esac

say ""
say "Verificação:"
say "  Claude Code: abra uma sessão nova e rode /skills (ou digite /$NAME)."
say "  Codex: reinicie se a skill não aparecer e invoque \$$NAME."
