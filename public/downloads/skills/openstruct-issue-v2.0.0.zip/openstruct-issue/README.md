# openstruct-issue

Skill que prepara issues do GitHub claras e verificáveis para um agente de programação executar, em qualquer repositório. Ela **não** implementa nada.

Versão 2.0.0. O frontmatter usa só `name`, `description` e `metadata` (padrão Agent Skills).

## O que ela faz, em ordem

1. Lê o contexto do repositório com um script somente leitura.
2. **Confirma com você, sempre**, de onde ler, qual é o origin, se é fork e qual o pai, onde abrir a issue e qual o branch de base.
3. Lê as instruções do projeto e o código; nada é presumido sobre pilha, comando de teste ou convenção.
4. **Pergunta tudo o que muda o resultado** antes de redigir. Detalhe sem efeito vira suposição registrada.
5. Entrega a issue num layout único: topo para quem lê, bloco recolhível "Para o agente que for executar" no fim.
6. Publica só se você pedir, e confirma antes quando o repositório não é seu.

Quem executa a issue (Claude Code ou Codex, em outro computador, com outro modelo) não precisa desta skill: as regras de execução ficam no corpo da issue.

## Estrutura

```
openstruct-issue/
├── SKILL.md                    instruções principais
├── references/                 lidas sob demanda
│   ├── issue-template.md       layout, marcadores, matriz P/M/G, template do repositório
│   ├── como-executar.md        texto do bloco do agente e o lançador
│   ├── calculo-e-normas.md     material adicional para cálculo, critério e norma
│   ├── model-policy.md         capacidade recomendada, delegação
│   ├── model-map.yaml          único lugar com nomes de modelo (exemplos datados)
│   ├── platforms.md            o que Claude Code e Codex carregam sozinhos
│   ├── github-publishing.md    leitura, convenções, publicação, revisão de issue
│   └── quality-checklist.md    conferência antes de entregar
├── scripts/
│   ├── repo-context.sh         contexto do repositório, somente leitura
│   └── lint-issue.sh           verificador determinístico do corpo da issue
├── examples/                   exemplos completos (01–04, 07) e cenas curtas (05)
├── evals/                      testes e avaliação (não fazem parte do uso)
├── install.sh                  cópia para outra máquina, para um repositório ou para o Codex
└── VERIFICATION-NOTES.md       o que foi conferido, onde e quando
```

## Uso

```
/openstruct-issue a busca de contatos não acha "João" quando digito "joao"; quero uma issue
```

- Peça "rascunho" para receber o texto; peça "crie no GitHub" para publicar (exige `gh` autenticado).
- Rode de dentro do repositório, ou da pasta que contém vários: nesse caso a skill lista os repositórios e pergunta qual.

## Requisitos

- `git` e, para ler fork, permissão e issues ou para publicar, o GitHub CLI (`gh`) autenticado.
- Um bash. No Windows serve o que vem com o Git; a skill sabe chamá-lo a partir do PowerShell.

## Instalação

Para o Claude Code nesta máquina, a skill já está instalada: é esta pasta.

| Onde | Como |
|---|---|
| Outra máquina, pessoal | copie a pasta para `~/.claude/skills/openstruct-issue/` |
| Um repositório (colaboradores e sessões em nuvem) | `./install.sh claude-project <raiz-do-repo>` e commit |
| Codex | `./install.sh user` ou `./install.sh project <raiz>`. **Não testado no Codex** |

Sessões em nuvem não leem `~/.claude/skills/` da sua máquina: usam as skills da conta ou as commitadas em `.claude/skills/` do repositório.

## Testes e avaliação

```bash
bash evals/test-repo-context.sh     # script de contexto: repositórios descartáveis e gh falso, sem rede
bash evals/test-lint-issue.sh       # verificador
for f in examples/0[12347]*.md; do bash scripts/lint-issue.sh --blocos "$f"; done
bash evals/run-evals.sh <pasta-de-trabalho>    # 13 casos em sessões novas do Claude Code; consome tokens
```

Casos em `evals/cases.md`, resultados em `evals/RESULTS.md`.

## Manutenção

- Histórico em git local, nesta pasta. `.gitattributes` força LF: scripts de bash quebram com CRLF.
- Uma regra, um lugar. Os rótulos literais da issue estão em `scripts/lint-issue.sh`; nomes de modelo, só em `references/model-map.yaml`.
- Ao mudar o template ou o `SKILL.md`: rode os dois testes e o verificador nos exemplos; depois a avaliação.
- Antes de citar modelos, confira `verified_on` em `model-map.yaml`. Registre o que mudou em `VERIFICATION-NOTES.md`.
