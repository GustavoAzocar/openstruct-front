#!/usr/bin/env bash
# lint-issue.sh — verificador determinístico do corpo de uma issue da skill openstruct-issue.
# É a lista única de rótulos literais: o template, os exemplos e a avaliação conferem por aqui.
# Não usa rede, não altera o arquivo conferido. Compatível com bash 3.2.

set -u

usage() {
  cat <<'EOF'
Uso: bash lint-issue.sh [--blocos] [--publicar] <arquivo.md>

  (sem opção)  O arquivo é o corpo de UMA issue.
  --blocos     Confere cada bloco ````markdown do arquivo (resposta da skill ou exemplo).
  --publicar   Corpo prestes a ser publicado: o título não pode estar no corpo.

Saída: linhas "ERRO: …" e "AVISO: …". Código 0 sem erros, 1 com erros, 2 uso incorreto.
EOF
}

BLOCOS=0; PUBLICAR=0; ARQ=""
while [ $# -gt 0 ]; do
  case "$1" in
    --blocos) BLOCOS=1 ;;
    --publicar) PUBLICAR=1 ;;
    -h|--help) usage; exit 0 ;;
    -*) printf 'Opção desconhecida: %s\n' "$1" >&2; usage >&2; exit 2 ;;
    *) ARQ="$1" ;;
  esac
  shift
done
[ -n "$ARQ" ] && [ -f "$ARQ" ] || { usage >&2; exit 2; }

TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
ERROS=0; AVISOS=0; PFX=""
err() { printf 'ERRO: %s%s\n' "$PFX" "$1"; ERROS=$((ERROS + 1)); }
avi() { printf 'AVISO: %s%s\n' "$PFX" "$1"; AVISOS=$((AVISOS + 1)); }

lint_um() {  # arquivo (sem \r)
  local f="$1" st tam bloqueada=0 mae=0 calc=0 achado n
  tem()   { grep -q -F -- "$1" "$f"; }
  temre() { grep -q -E -- "$1" "$f"; }
  exige() { tem "$1" || err "falta o rótulo '$1'"; }

  # ---- status e tamanho
  if ! tem "Status:"; then
    err "falta a linha 'Status:'"; st=""
  else
    st="$(grep -m 1 -F 'Status:' "$f" | sed -e 's/.*Status://' -e 's/·.*//' -e 's/[*`]//g' -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"
    case "$st" in
      PRONTA) ;;
      "RASCUNHO BLOQUEADO") bloqueada=1 ;;
      *) err "Status fora dos dois valores (PRONTA, RASCUNHO BLOQUEADO): '$st'" ;;
    esac
  fi
  tam="$(grep -m 1 -o -E 'Tamanho:[*`[:space:]]*[PMG]([^A-Za-z]|$)' "$f" | sed -E 's/.*([PMG]).?$/\1/')"
  if [ -z "$tam" ] && [ "$bloqueada" = 0 ]; then err "falta 'Tamanho: P|M|G'"; fi
  temre 'Tamanho:[*`[:space:]]*G[^A-Za-z]*\(issue-m' && mae=1
  temre 'C.{1,2}lculo/norma:[*`[:space:]]*sim' && calc=1
  temre 'C.{1,2}lculo/norma:[*`[:space:]]*(sim|n.{1,2}o)' || err "falta 'Cálculo/norma: sim|não'"

  # ---- rótulos obrigatórios
  exige "Resultado esperado:"
  if [ "$bloqueada" = 1 ]; then
    exige "Falta para ficar PRONTA:"
  else
    exige "Fora do escopo"
    exige "Ambiente necessário"
    exige "Pare e pergunte se"
    exige "Como executar"
    tem "- [ ]" || err "falta ao menos um critério de aceite em caixa de seleção ('- [ ]')"
    if ! tem "Lido em " && ! tem "Não verificado"; then
      err "falta a linha de verificação ('Lido em <repo>@<branch> <sha> (<data>)') ou a seção 'Não verificado'"
    fi
    case "$tam" in
      M|G)
        exige "Suposições adotadas:"
        exige "Plano de validação" ;;
    esac
    [ "$mae" = 1 ] && exige "Plano de sub-issues"
    if [ "$calc" = 1 ]; then
      exige "Fórmulas, regras e fontes"
      exige "Exemplo numérico"
    fi
  fi

  # ---- restos de preenchimento
  tem '#<' && err "resto de preenchimento: '#<…>' (número de issue não trocado)"
  # palavra inteira logo depois de "<": <URL>, <comando de teste>, <N>. Não pega <database> nem <details>.
  achado="$(grep -n -i -o -E '<(url|n|sha|branch|data|comando|caminho|dono|owner|slug|t.{1,2}tulo|verbo|resultado|arquivo|valor|n.{1,2}mero|quem|outro)([^A-Za-z<>][^<>]{0,40})?>' "$f" | head -n 3 | tr '\n' ' ')"
  if [ -n "$achado" ]; then
    if [ "$bloqueada" = 1 ]; then avi "resto de preenchimento em rascunho bloqueado: $achado"
    else err "resto de preenchimento: $achado"; fi
  fi
  temre '\(ver (abaixo|acima)\)' && err "resto de rascunho: '(ver abaixo)' ou '(ver acima)'"

  # ---- o executor não tem a skill nem a máquina do autor
  achado="$(grep -n -o -E 'executor-prompt\.md|como-executar\.md|model-map\.yaml|model-policy\.md|issue-template\.md|quality-checklist\.md|github-publishing\.md|calculo-e-normas\.md|platforms\.md|repo-context\.sh|lint-issue\.sh|openstruct-issue' "$f" | head -n 3 | tr '\n' ' ')"
  [ -n "$achado" ] && err "referência a arquivo da skill, que o leitor não tem: $achado"
  achado="$(grep -n -o -E '(^|[^A-Za-z])[A-Za-z]:[\\/][A-Za-z0-9_.~-]+|(^|[[:space:]`(])(/c/|/Users/|/home/|~/)[A-Za-z0-9_.~-]+' "$f" | head -n 3 | tr '\n' ' ')"
  [ -n "$achado" ] && err "caminho absoluto ou da máquina do autor (use caminho relativo à raiz do repositório): $achado"
  achado="$(grep -n -o -E '(^|[^A-Za-z0-9])C[1-4]([^A-Za-z0-9]|$)' "$f" | head -n 3 | tr '\n' ' ')"
  [ -n "$achado" ] && err "código de perfil C1–C4 no corpo (descreva a capacidade em palavras): $achado"

  # ---- título
  if [ "$PUBLICAR" = 1 ]; then
    if head -n 1 "$f" | grep -q -E '^# '; then err "o corpo começa com '# título': na publicação o título vai em --title"; fi
  elif [ "$BLOCOS" = 1 ]; then
    if ! grep -m 1 -v -E '^[[:space:]]*$' "$f" | grep -q -E '^# '; then err "o bloco deve começar com a linha '# <título>'"; fi
  fi

  # ---- proporcionalidade
  if [ "$tam" = "P" ]; then
    n="$(wc -w < "$f" | tr -d ' ')"
    [ "$n" -gt 380 ] && avi "issue P com $n palavras (a meta é cerca de 300)"
  fi
  return 0
}

tr -d '\r' < "$ARQ" > "$TMP/entrada.md"
if [ "$BLOCOS" = 1 ]; then
  awk -v dir="$TMP" '
    /^````markdown[[:space:]]*$/ && !dentro { dentro = 1; n++; next }
    /^````[[:space:]]*$/ && dentro { dentro = 0; next }
    dentro { print > (dir "/bloco-" n ".md") }
    END { print n + 0 > (dir "/total") }
  ' "$TMP/entrada.md"
  total="$(cat "$TMP/total" 2>/dev/null || echo 0)"
  if [ "$total" = 0 ]; then
    printf 'ERRO: nenhum bloco ````markdown encontrado em %s\n' "$ARQ"; exit 1
  fi
  i=1
  while [ "$i" -le "$total" ]; do
    PFX="bloco $i de $total: "
    [ -f "$TMP/bloco-$i.md" ] && lint_um "$TMP/bloco-$i.md"
    i=$((i + 1))
  done
else
  lint_um "$TMP/entrada.md"
fi

printf 'Verificador: %s erro(s), %s aviso(s)\n' "$ERROS" "$AVISOS"
[ "$ERROS" = 0 ]
