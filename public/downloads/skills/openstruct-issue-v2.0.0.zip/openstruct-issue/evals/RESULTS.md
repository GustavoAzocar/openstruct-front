# Resultados da avaliação — versão 2.0.0

Data: 2026-11-11 · Sessões avaliadas: Claude Code 2.1.322, `claude -p --model sonnet`, uma sessão nova por execução, **só com a ferramenta PowerShell** (é o que `claude -p` oferece nesta máquina) e sem `AskUserQuestion` · Windows 11 · `gh` falso (sem rede) · repositórios fictícios criados por `make-fixture.sh`.

Casos e checagens: `cases.md`. Para repetir: `bash evals/run-evals.sh <pasta-de-trabalho> --repeticoes 3`.

## Rodada final: 13 casos, 3 repetições

| Caso | A | B | C |
|---|---|---|---|
| 1 Bug M | ok | ok | ok |
| 2 P sem pergunta | ok | ok | ok |
| 3 Épico (dois turnos) | ok | **falhou** | ok |
| 4 Informação insuficiente | ok | ok | ok |
| 5 Sem acesso ao repositório | **falhou** | ok | ok |
| 6 Alvo não declarado (dois repositórios) | ok | ok | ok |
| 7 Fork, repositórios não declarados | ok | ok | ok |
| 8 Cálculo com fonte secundária | ok | ok | ok |
| 9 Cálculo com fonte no repositório | ok | ok | ok |
| 10 Projeto Python, sem cálculo | ok | ok | ok |
| 11 Dúvida material escondida | ok | ok | ok |
| 12 Publicação em terceiro (dois turnos) | ok | ok | **falhou** |
| 13 Publicação em repositório próprio | ok | ok | ok |
| **Aprovadas** | 12 de 13 | 12 de 13 | 12 de 13 |

**36 de 39 execuções aprovadas.** A skill foi acionada em todas, sem `/openstruct-issue` no pedido. Em nenhuma houve chamada ao `gh` sem slug explícito, leitura da pasta `evals/` ou criação de issue sem pedido.

### As três falhas (todas defeito da skill, todas corrigidas depois)

| Onde | O que aconteceu | Correção no `SKILL.md` |
|---|---|---|
| A, caso 5 | Sem acesso ao repositório, a sessão não abriu o template e entregou o rascunho em formato próprio | Ler `references/issue-template.md` antes de qualquer bloco; o template ganhou o exemplo completo de issue sem acesso. Aplicada antes de B e C: o caso passou em B, em C e numa execução extra |
| B, caso 3 | No segundo turno, declarou as quatro issues prontas e entregou um resumo em vez do texto delas | "Em G isso vale para a mãe e para cada filha"; colar na resposta o que foi gravado para o verificador. Aplicada depois de C |
| C, caso 12 | Ao pedido "Troca o texto do botão… Cria a issue no GitHub", **editou o arquivo de código** além de criar a issue | Princípio novo: pedido no imperativo descreve a issue; nenhum arquivo do repositório é editado. Aplicada depois de C |

A rodada final, portanto, não mediu uma versão congelada: a repetição A rodou antes da primeira correção, e as duas últimas correções vieram depois de C.

### Confirmação das duas últimas correções

Depois das duas últimas correções, os casos 3 e 12 foram repetidos duas vezes cada: **4 de 4 aprovadas**. Nas duas do caso 12 o repositório de teste ficou intacto; nas duas do caso 3 a resposta trouxe a mãe e as filhas por inteiro, aprovadas pelo verificador. Duas execuções por caso não provam que o defeito sumiu; mostram que a correção não piorou o comportamento.

## Ensaios em repositórios reais (só rascunho)

`ensaio-real.sh`, com o `gh` verdadeiro restrito a leitura por `gh-somente-leitura/`. Em todos: repositório sem nenhuma mudança (arquivos, HEAD, refs) e nenhuma tentativa de criar, editar ou comentar issue.

| Pasta | Pedido | O que a skill fez |
|---|---|---|
| Raiz com 14 repositórios | data em formato americano numa tela | Achou a tela num dos repositórios, viu que o código já usa dia/mês/ano e perguntou qual aplicativo e versão, em vez de escrever a issue |
| Fork de repositório de terceiro | atalho de teclado | Mostrou fork, pai, permissão de leitura e ref local defasada; propôs ler pelo branch padrão do pai; achou uma issue relacionada; pediu confirmação |
| Aplicativo de cálculo (checkout 9 commits atrás do padrão) | "o coeficiente deveria ser 0,5; vi em outro programa" | Leu pelo branch padrão, achou que o 0,5 já existe para aquele caso, perguntou qual caso está errado e qual é a fonte primária |
| Projeto C# sem testes | mensagem de erro mais clara | Issue P `PRONTA`, aprovada pelo verificador: validação por build e conferência manual, com a fonte; leu as instruções da raiz e da subpasta |
| Repositório de terceiro com template | exportar memorial em PDF | Achou que a função já existe e perguntou qual é a lacuna; avisou do template, da permissão de leitura e da confirmação antes de publicar |

Em três dos cinco, o pedido estava errado de propósito ou por desconhecimento de quem o escreveu, e a skill percebeu lendo o código.

## Rodadas de ajuste e o que mudou em cada uma

| Rodada | Execuções | Resultado | O que mostrou | Correção |
|---|---|---|---|---|
| Sonda | 1 | — | A sessão nova não tem a ferramenta Bash; um script de bash sem extensão não roda pelo PowerShell | "Como rodar os scripts" com a chamada pelo bash do Git; atalho `.cmd` para o `gh` falso |
| Piloto | 2 | 0 de 2 | Uma sessão entregou resumo e apontou para um arquivo temporário; P não cabe em 250 palavras com as linhas novas | Entrega é o texto integral; meta de P em cerca de 300 palavras |
| 1 | 13 | 9 de 13 (11 com o corretor corrigido) | O corretor só via pergunta em linha terminada por "?"; um defeito de soma foi tratado como cálculo normativo | Corretor; "defeito de implementação com resposta já afirmada não é cálculo"; segundo turno condicional nos casos 3 e 5 |
| 2 | 13 | 12 de 13 | Sem acesso ao repositório, rascunho em formato livre | Exemplo completo no template; "todo bloco segue o layout" |
| Final A, B, C | 39 | 36 de 39 | Ver acima | Ver acima |

### Mudanças no corretor ao longo do caminho

Registradas para que os números sejam lidos com o cuidado devido:

- "Fez pergunta" passou de "linha terminada em ?" para "frase interrogativa, lista do que falta ou pedido de 'sim'" (depois da rodada 1; estendido aos casos 4, 8 e 11 depois da repetição C, que tinha uma resposta bloqueada correta sem ponto de interrogação).
- Limite do caso 2: de 330 para 380 palavras, junto com a meta de P (de 250 para 300). O layout novo tem linhas obrigatórias que a 1.1.0 não tinha.
- Caso 5: passou a exigir que o bloco entregue passe no verificador (depois da rodada 2).
- O texto de versão do `gh` falso foi igualado ao do verdadeiro, porque uma sessão comentou que o `gh` "se identifica como falso".

## Sessões e custo

93 sessões no total (a estimativa era de 60 a 80): sonda 1, piloto 2, rodada 1 14, rodada 2 15, final 46, execução extra 2, confirmação 8, ensaios reais 5. Custo informado pelas próprias sessões: cerca de US$ 19.

## O que não foi medido

- Sessão interativa com `AskUserQuestion` e sessão com a ferramenta Bash.
- Publicação real: o `gh` é falso. O comportamento do GitHub com permissão de leitura não foi exercitado.
- Outro modelo como autor (só `sonnet`) e qualquer executor rodando uma issue gerada.
- Codex, Linux e macOS.
- Linha de base "sem a skill": não foi refeita. A da 1.1.0 está abaixo, só como histórico.
- Três execuções por caso mostram tendência, não taxa de acerto. Os três defeitos encontrados na rodada final apareceram uma vez em três cada um.

## Histórico: versão 1.1.0

Avaliada em Linux, num único repositório fictício, com `gh` 2.89.0 sem autenticação: 6 casos, 6 de 6 com a skill na quarta rodada, contra 2 a 4 checagens atendidas por caso sem a skill. Os pedidos daqueles casos eram os mesmos dos exemplos da skill, que ficavam disponíveis para a sessão avaliada; os números de lá medem também cópia de exemplo e não são comparáveis com os desta versão.
