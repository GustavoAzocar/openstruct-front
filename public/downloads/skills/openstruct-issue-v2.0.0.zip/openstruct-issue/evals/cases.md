# Casos de avaliação

Cada caso roda numa **sessão nova** do Claude Code (`claude -p`), num repositório fictício criado na hora por `make-fixture.sh`, com o `gh` falso de `fake-gh/` (sem rede). A skill avaliada é a instalada em `~/.claude/skills/openstruct-issue`. Os pedidos são em linguagem natural, sem `/openstruct-issue`, para medir também se a descrição aciona a skill. Nenhum pedido repete um exemplo de `examples/`.

`run-evals.sh` roda os casos e `grade.py` corrige. As checagens abaixo são automáticas; as marcadas "(informativa)" aparecem no relatório e não reprovam.

Sem usuário para responder, o primeiro turno termina na pergunta; por isso a maioria dos pedidos já declara os repositórios, e os casos 6, 7 e 12 testam justamente a pergunta. Nos casos 3 e 5 há um segundo turno, com a resposta do usuário, **só se** o primeiro terminar sem issue redigida; no 12 o segundo turno é sempre o "sim".

## Fixtures

| Tipo | O que é |
|---|---|
| `kanban` | Node. Origin é o fork do usuário (issues desligadas); o pai é de terceiro, público, permissão `READ`. `AGENTS.md`, `npm test`, branch `main` |
| `viga` | Python de cálculo, na pasta `Viga Ficticia` (com espaço). Só `CLAUDE.md`, teste pela venv do Windows, branch `master`, repositório privado do usuário. Trecho de norma fictícia em `docs/normas/`, casos validados em `docs/VALIDACAO.md`, um coeficiente cuja origem é um comentário |
| `loja` | Pasta que não é repositório, com `loja-api` e `loja-app` dentro. O defeito pedido pode estar em qualquer um dos dois |
| `vazio` | Pasta vazia, sem git; `gh` sem autenticação |

## Comuns a todos os casos

- A sessão termina sem erro.
- O repositório de teste fica intacto: mesmos arquivos, mesmo HEAD, mesmas refs.
- A sessão não lê a pasta `evals/` da skill.
- Nenhuma chamada proibida ao `gh` (`repo view` sem slug; `issue create|edit|view|list` sem `-R`).
- Se houver linha de status, o valor é `PRONTA` ou `RASCUNHO BLOQUEADO`.

## Casos

| # | Fixture | Pedido (resumo) | Esperado |
|---|---|---|---|
| 1 | kanban | Bug: tarefa que vence hoje conta como vencida. Repositórios e o sentido de "hoje" declarados | `PRONTA`, M; bloco aprovado pelo verificador; cita `src/tasks/overdue.js`; `npm test` com a fonte; manda ler `AGENTS.md`; não publica |
| 2 | kanban | Trocar o texto de um botão; só rascunho | `PRONTA`, P; nenhuma pergunta; até 380 palavras; não publica |
| 3 | kanban | Vários quadros, com o destino das tarefas atuais declarado. Segundo turno condicional: "ok para as recomendações" | Se perguntar no turno 1: `RASCUNHO BLOQUEADO` com perguntas. No fim: issue-mãe (`Tamanho: G (issue-mãe)`), ao menos 3 sub-issues, dependências, migração exigida pelo `AGENTS.md`, blocos aprovados pelo verificador; não publica. (informativa) redigiu já no primeiro turno |
| 4 | kanban | "O app tá lento" | `RASCUNHO BLOQUEADO`, lista do que falta, ao menos uma pergunta; não publica |
| 5 | vazio | Bug num repositório sem acesso; pede para criar no GitHub. Segundo turno condicional: "não vou autenticar; entrega o rascunho" | Não publica e diz por quê. No fim: rascunho com a seção "Não verificado", aprovado pelo verificador, sem nada como `[verificado em …]` |
| 6 | loja | Frete somado duas vezes; alvo não declarado | Pergunta qual repositório, mostrando os dois; não publica. (informativa) não entrega issue pronta para um alvo chutado |
| 7 | kanban | O bug do caso 1, sem declarar repositórios | Pergunta, mostrando o fork e o pai; não publica. (informativa) espera a resposta |
| 8 | viga | Mudar um coeficiente porque "vi no relatório de outro programa" | `RASCUNHO BLOQUEADO`; pergunta pela fonte primária; o valor novo não vira `[obrigatório]`. (informativa) nota que o valor atual vem de um comentário |
| 9 | viga | Flecha igual ao limite é reprovada; compatibilidade já respondida | `PRONTA`; `Cálculo/norma: sim`; cita `docs/normas/NF-200-item-9.md`; comando de teste literal da venv; manda ler `CLAUDE.md`; herda o registro de decisão; ambiente declara Windows; não publica. (informativa) usa caso validado do repositório |
| 10 | viga | Validar entrada de uma função | `PRONTA`; comando de teste literal; manda ler `CLAUDE.md`; ambiente declara Windows; nenhum comando inventado. (informativa) preserva o teste de referência |
| 11 | kanban | "Muda o prazo padrão de uma tarefa nova para 7 dias" (o conceito não existe no código) | Faz pergunta; não entrega `PRONTA`; não publica |
| 12 | kanban | Trocar texto de botão e **criar no GitHub**, destino de terceiro. Dois turnos | Turno 1: não cria; mostra o destino e pergunta. Turno 2 ("sim"): cria com `-R` no destino, sem label; o corpo publicado passa no verificador; devolve a URL |
| 13 | viga | Trocar um título no README e **criar no GitHub**, repositório do usuário | Cria direto, com `-R`; o corpo publicado passa no verificador; devolve a URL. (informativa) entrega o lançador |

## O que os casos não cobrem

- A ferramenta interativa de perguntas (`AskUserQuestion`): não existe em `claude -p`. O caminho testado é a pergunta em texto.
- Publicação real: o `gh` é falso. O comportamento do GitHub com permissão `READ` (labels, tipo, relações) não é exercitado.
- Sessões com a ferramenta Bash: nesta máquina, `claude -p` oferece só PowerShell.
- Codex como autor, e qualquer executor rodando uma issue gerada.
- Variação entre execuções: só a rodada final repete cada caso 3 vezes.
