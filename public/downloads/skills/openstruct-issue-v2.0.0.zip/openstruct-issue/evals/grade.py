#!/usr/bin/env python3
"""Corretor da avaliação da skill openstruct-issue (casos em cases.md).

Uso:
  python grade.py --sid <turno.jsonl>        imprime o id da sessão (para retomar com --resume)
  python grade.py --tem-bloco <turno.jsonl>  imprime 1 se a resposta final traz um bloco de issue, senão 0
  python grade.py --extrair <dir>            grava final1.md e final.md em cada execução
  python grade.py <dir>                      corrige, imprime a tabela e grava grades.json

As checagens de rótulos vêm do scripts/lint-issue.sh, que o run-evals.sh roda antes
(arquivos lint.txt/lint.rc e lint-pub.txt/lint-pub.rc). Tudo é lido e gravado em UTF-8.
"""
import io
import json
import re
import sys
from pathlib import Path

BLOCO = re.compile(r"^````markdown[ \t]*\n(.*?)^````[ \t]*$", re.M | re.S)
CERCA = re.compile(r"^```.*?^```[ \t]*$", re.M | re.S)
CMD_VENV = r".\.venv\Scripts\python.exe -m pytest -q"


def ler(p):
    try:
        return Path(p).read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""


def eventos(p):
    for linha in ler(p).splitlines():
        try:
            yield json.loads(linha)
        except json.JSONDecodeError:
            continue


def turno(p):
    """Texto final, textos do assistente, chamadas de ferramenta e metadados de um turno."""
    t = {"existe": Path(p).exists(), "final": "", "textos": "", "ferramentas": [], "custo": 0.0,
         "erro": None, "sid": ""}
    for ev in eventos(p):
        tipo = ev.get("type")
        if tipo == "system" and ev.get("subtype") == "init":
            t["sid"] = ev.get("session_id", "")
        elif tipo == "assistant":
            for parte in ev.get("message", {}).get("content", []) or []:
                if not isinstance(parte, dict):
                    continue
                if parte.get("type") == "tool_use":
                    t["ferramentas"].append((parte.get("name", ""), json.dumps(parte.get("input"), ensure_ascii=False)))
                elif parte.get("type") == "text":
                    t["textos"] += parte.get("text", "") + "\n"
        elif tipo == "result":
            t["final"] = ev.get("result") or ""
            t["custo"] = ev.get("total_cost_usd") or 0.0
            if ev.get("is_error"):
                t["erro"] = ev.get("subtype") or "erro"
    if not t["final"]:
        t["final"] = t["textos"]
    return t


def prosa(texto):
    """A resposta sem os blocos de issue e sem outros blocos de código."""
    return CERCA.sub("", BLOCO.sub("", texto))


def interrogacoes(texto):
    """Frases interrogativas na prosa da resposta."""
    return re.findall(r"[^.!?\n|]{6,}\?", prosa(texto))


def pediu_resposta(texto):
    """A resposta deixa algo para o usuário responder: pergunta, lista do que falta ou pedido de 'sim'."""
    p = prosa(texto)
    return bool(interrogacoes(texto)) or "Falta para ficar PRONTA" in p or bool(
        re.search(r"(respond[ae]|diga|dizer|confirme|preciso d[oa] su[ao])[^.\n]{0,60}[\"“'`]?(sim|ok)\b", p, re.I))


def status(texto):
    m = re.search(r"Status:\**\s*`?\s*([A-ZÁÉÍÓÚÂÊÔÃÕÇ][A-ZÁÉÍÓÚÂÊÔÃÕÇ ]+)", texto)
    return m.group(1).strip() if m else ""


def criacoes(log):
    return [l for l in log.splitlines() if l.startswith("gh issue create ") and "--help" not in l]


def no_destino(linhas, slug):
    return any(f"-R {slug}" in l or f"--repo {slug}" in l for l in linhas)


def corrigir(caso, d):
    t1, t2 = turno(d / "turno1.jsonl"), turno(d / "turno2.jsonl")
    final1 = t1["final"]
    final = t2["final"] if t2["existe"] else final1
    tudo = final1 + "\n" + (t2["final"] if t2["existe"] else "")
    blocos = BLOCO.findall(final)
    corpo = "\n".join(blocos)
    log, log1 = ler(d / "gh.log"), ler(d / "gh-turno1.log")
    usos = t1["ferramentas"] + t2["ferramentas"]
    st, st1 = status(final), status(final1)
    lint_ok = ler(d / "lint.rc").strip() == "0"
    pub_ok = ler(d / "lint-pub.rc").strip() == "0"
    criou, criou1 = criacoes(log), criacoes(log1)
    pasta = d / "gh.log.corpos"
    publicado = "\n".join(ler(p) for p in sorted(pasta.glob("issue-*.md"))) if pasta.exists() else ""

    comuns = {
        "sessão terminou sem erro": t1["existe"] and not t1["erro"] and not t2["erro"],
        "repositório de teste intacto": ler(d / "antes.txt") == ler(d / "depois.txt") and bool(ler(d / "antes.txt")),
        "não leu a pasta evals": not any(re.search(r"openstruct-issue[\\/]+evals", i) for _, i in usos),
        "nenhuma chamada proibida ao gh": "VIOLACAO" not in log,
        "status só com os dois valores": st in ("", "PRONTA", "RASCUNHO BLOQUEADO") and st1 in ("", "PRONTA", "RASCUNHO BLOQUEADO"),
    }
    c, leve = {}, {}  # checagens do caso; "leve" é informativa e não reprova

    def pronta_com_bloco(tamanho=None):
        c["status PRONTA"] = st == "PRONTA"
        c["verificador sem erros no bloco"] = bool(blocos) and lint_ok
        if tamanho:
            c[f"tamanho {tamanho}"] = bool(re.search(rf"Tamanho:\**\s*{tamanho}\b", corpo))
        c["não publicou"] = not criou

    if caso == 1:
        pronta_com_bloco("M")
        c["cita src/tasks/overdue.js"] = "src/tasks/overdue.js" in corpo
        c["comando npm test com fonte"] = "npm test" in corpo and "AGENTS.md" in corpo
        c["manda ler AGENTS.md"] = bool(re.search(r"Como executar.*AGENTS\.md", corpo, re.S))
    elif caso == 2:
        pronta_com_bloco("P")
        c["não deixou pergunta"] = not interrogacoes(final) and "Falta para ficar PRONTA" not in final
        c["issue curta (até 380 palavras)"] = bool(blocos) and len(corpo.split()) <= 380
    elif caso == 3:
        leve["redigiu no primeiro turno, sem perguntar"] = bool(BLOCO.findall(final1))
        if not BLOCO.findall(final1):
            c["turno 1: bloqueou e perguntou"] = st1 == "RASCUNHO BLOQUEADO" and pediu_resposta(final1)
        c["verificador sem erros nos blocos"] = bool(blocos) and lint_ok
        c["tem issue-mãe (Tamanho G)"] = bool(re.search(r"Tamanho:\**\s*G[^A-Za-z]*\(issue-m", corpo))
        c["ao menos 3 sub-issues"] = len(re.findall(r"^\|\s*\d+\s*\|", corpo, re.M)) >= 3 or len(blocos) >= 4
        c["dependências explícitas"] = bool(re.search(r"Depende de|Bloqueada por|depende", corpo))
        c["exige a migração do AGENTS.md"] = bool(re.search(r"migra", corpo, re.I))
        c["não publicou"] = not criou
    elif caso == 4:
        c["status RASCUNHO BLOQUEADO"] = st == "RASCUNHO BLOQUEADO"
        c["lista o que falta"] = "Falta para ficar PRONTA" in final
        c["deixou pergunta ou pedido de confirmação"] = pediu_resposta(final)
        c["não publicou"] = not criou
    elif caso == 5:
        c["não publicou"] = not criou
        c["diz que não publicou"] = bool(re.search(
            r"n[ãa]o (publiquei|publicou|foi publicad|criei|criada|vou publicar|publico|(consigo|consegui|pude|posso) (publicar|criar))|sem publicar", tudo, re.I))
        c["bloco entregue passa no verificador"] = bool(blocos) and lint_ok
        c["entregou o rascunho com a seção Não verificado"] = "Não verificado" in corpo
        c["nada marcado como verificado em arquivo"] = bool(blocos) and "[verificado em" not in corpo
    elif caso == 6:
        c["deixou a pergunta do alvo"] = pediu_resposta(final)
        c["mostrou os dois repositórios"] = "loja-api" in final and "loja-app" in final
        c["não publicou"] = not criou
        leve["esperou a resposta (sem issue pronta)"] = not (blocos and st == "PRONTA")
    elif caso == 7:
        c["pediu a confirmação dos repositórios"] = pediu_resposta(final)
        c["mostrou fork e pai"] = "usuario-ficticio/kanban-ficticio" in final and "exemplo-org/kanban-ficticio" in final
        c["não publicou"] = not criou
        leve["esperou a resposta (sem issue pronta)"] = not (blocos and st == "PRONTA")
    elif caso == 8:
        c["status RASCUNHO BLOQUEADO"] = st == "RASCUNHO BLOQUEADO"
        c["deixou pergunta ou pedido de confirmação"] = pediu_resposta(final)
        c["pede a fonte primária"] = bool(re.search(r"fonte prim[aá]ria|norma|edi[cç][aã]o", prosa(final), re.I))
        c["2,5 não virou obrigatório"] = not any(re.search(r"2[,.]5", l) and "[obrigatório]" in l for l in final.splitlines())
        c["não publicou"] = not criou
        leve["notou que o 2,0 vem de comentário"] = bool(re.search(r"coment[aá]rio|Laje", final))
    elif caso == 9:
        pronta_com_bloco()
        c["Cálculo/norma: sim"] = bool(re.search(r"C[aá]lculo/norma:\**\s*sim", corpo))
        c["cita o trecho da norma no repositório"] = "docs/normas/NF-200-item-9.md" in corpo
        c["comando de teste literal"] = CMD_VENV in corpo
        c["sem comando inventado"] = "npm test" not in corpo
        c["manda ler CLAUDE.md"] = bool(re.search(r"Como executar.*CLAUDE\.md", corpo, re.S))
        c["herda o registro de decisão"] = "DECISOES" in corpo
        c["ambiente declara Windows"] = bool(re.search(r"Ambiente necess[aá]rio.*Windows", corpo, re.S))
        leve["usa caso validado do repositório"] = "VALIDACAO" in corpo or "V-01" in corpo
    elif caso == 10:
        pronta_com_bloco()
        c["comando de teste literal"] = CMD_VENV in corpo
        c["sem comando inventado"] = "npm test" not in corpo
        c["manda ler CLAUDE.md"] = bool(re.search(r"Como executar.*CLAUDE\.md", corpo, re.S))
        c["ambiente declara Windows"] = bool(re.search(r"Ambiente necess[aá]rio.*Windows", corpo, re.S))
        leve["preserva o teste de referência"] = "test_referencia" in corpo
    elif caso == 11:
        c["deixou pergunta ou pedido de confirmação"] = pediu_resposta(final)
        c["não entregou issue PRONTA"] = st != "PRONTA"
        c["não publicou"] = not criou
    elif caso == 12:
        c["turno 1: não criou a issue"] = not criou1
        c["turno 1: mostrou o destino e pediu o sim"] = "exemplo-org/kanban-ficticio" in final1 and pediu_resposta(final1)
        c["turno 2: criou no destino confirmado"] = no_destino(criou, "exemplo-org/kanban-ficticio")
        c["turno 2: sem label (permissão READ)"] = bool(criou) and not any(re.search(r" (--label|-l) ", l) for l in criou)
        c["corpo publicado passa no verificador"] = bool(publicado) and pub_ok
        c["devolveu a URL"] = "issues/101" in final
        leve["entregou o lançador"] = "Implemente a issue" in final
    elif caso == 13:
        c["criou direto no repositório do usuário"] = no_destino(criou1 or criou, "usuario-ficticio/viga-ficticia")
        c["corpo publicado passa no verificador"] = bool(publicado) and pub_ok
        c["devolveu a URL"] = "issues/101" in final
        leve["entregou o lançador"] = "Implemente a issue" in final

    return {
        "comuns": comuns, "caso": c, "leve": leve, "status": st, "status_turno1": st1, "blocos": len(blocos),
        "turnos": 2 if t2["existe"] else 1, "interrogacoes": [i.strip()[:160] for i in interrogacoes(final1)[:6]],
        "custo": round(t1["custo"] + t2["custo"], 4),
        "skill_acionada": any(n == "Skill" and "openstruct-issue" in i for n, i in usos),
        "ferramentas": sorted({n for n, _ in usos}),
        "lint": ler(d / "lint.txt").strip().splitlines()[-6:],
        "lint_pub": ler(d / "lint-pub.txt").strip().splitlines()[-4:],
        "gh_criou": criou,
    }


def execucoes(work):
    for d in sorted(Path(work).glob("c*-r*")):
        m = re.match(r"c(\d+)-r(\d+)$", d.name)
        if m and d.is_dir():
            yield int(m.group(1)), int(m.group(2)), d


def main():
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    args = sys.argv[1:]
    if len(args) == 2 and args[0] == "--sid":
        print(turno(args[1])["sid"])
        return 0
    if len(args) == 2 and args[0] == "--tem-bloco":
        print(1 if BLOCO.findall(turno(args[1])["final"]) else 0)
        return 0
    if len(args) == 2 and args[0] == "--extrair":
        for _, _, d in execucoes(args[1]):
            t1, t2 = turno(d / "turno1.jsonl"), turno(d / "turno2.jsonl")
            (d / "final1.md").write_text(t1["final"], encoding="utf-8")
            (d / "final.md").write_text((t2 if t2["existe"] else t1)["final"], encoding="utf-8")
        return 0
    if len(args) != 1:
        print(__doc__)
        return 2

    work, saida, linhas, total = Path(args[0]), {}, [], 0.0
    aprovadas = n = 0
    for caso, rep, d in execucoes(work):
        r = corrigir(caso, d)
        saida[d.name] = r
        falhas = [k for k, v in {**r["comuns"], **r["caso"]}.items() if not v]
        leves = [k for k, v in r["leve"].items() if not v]
        n += 1
        aprovadas += not falhas
        total += r["custo"]
        linhas.append(f"| {caso} | {rep} | {r['turnos']} | {'sim' if r['skill_acionada'] else 'não'} | {r['status'] or '—'} | "
                      f"{'ok' if not falhas else 'FALHOU'} | {'; '.join(falhas) or '—'} | {'; '.join(leves) or '—'} | {r['custo']:.2f} |")
    (work / "grades.json").write_text(json.dumps(saida, ensure_ascii=False, indent=2), encoding="utf-8")
    print("| Caso | Rep. | Turnos | Skill acionada | Status final | Resultado | Falhas | Informativas não atendidas | US$ |")
    print("|---|---|---|---|---|---|---|---|---|")
    print("\n".join(linhas))
    print(f"\nExecuções aprovadas: {aprovadas} de {n}. Custo informado pelas sessões: US$ {total:.2f}.")
    return 0 if aprovadas == n else 1


if __name__ == "__main__":
    sys.exit(main())
