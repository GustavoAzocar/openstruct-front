#!/usr/bin/env bash
# Avaliação da skill openstruct-issue: roda cada caso de evals/cases.md numa sessão nova do
# Claude Code (claude -p), num repositório fictício descartável, com o gh FALSO (sem rede).
# A skill avaliada é a instalada em ~/.claude/skills/openstruct-issue.
#
# Uso: bash evals/run-evals.sh <diretório-de-trabalho> [opções]
#   --modelo M        modelo das sessões (padrão: sonnet)
#   --repeticoes N    execuções por caso (padrão: 1)
#   --casos "1 2 9"   só estes casos (padrão: todos)
#   --paralelo N      sessões simultâneas (padrão: 3)
#   --teto USD        teto de gasto por sessão (padrão: 2.00)
#   --so-corrigir     não roda sessões; só corrige o que já está no diretório
#
# Requer: claude autenticado, git, python 3. Compatível com bash 3.2.
# Segurança: o gh real fica sem credencial (GH_TOKEN inválido e GH_CONFIG_DIR vazio); nenhum
# servidor MCP é carregado (--strict-mcp-config); os repositórios são criados do zero.
set -u
WORK=""; MODEL="sonnet"; REPS=1; CASOS="1 2 3 4 5 6 7 8 9 10 11 12 13"; PAR=3; TETO="2.00"; SO_CORRIGIR=0
while [ $# -gt 0 ]; do
  case "$1" in
    --modelo) MODEL="$2"; shift ;;
    --repeticoes) REPS="$2"; shift ;;
    --casos) CASOS="$2"; shift ;;
    --paralelo) PAR="$2"; shift ;;
    --teto) TETO="$2"; shift ;;
    --so-corrigir) SO_CORRIGIR=1 ;;
    -h|--help) sed -n '2,/^set -u/p' "$0" | sed '$d' | sed 's/^# \{0,1\}//'; exit 0 ;;
    -*) echo "Opção desconhecida: $1" >&2; exit 2 ;;
    *) WORK="$1" ;;
  esac
  shift
done
[ -n "$WORK" ] || { echo "Informe o diretório de trabalho." >&2; exit 2; }
HERE="$(cd "$(dirname "$0")" && pwd -P)"; SKILL="$(cd "$HERE/.." && pwd -P)"
mkdir -p "$WORK"; WORK="$(cd "$WORK" && pwd -P)"
PY="$(command -v python3 || command -v python)" || { echo "python não encontrado" >&2; exit 1; }
mista() { if command -v cygpath >/dev/null 2>&1; then cygpath -m "$1"; else printf '%s' "$1"; fi; }  # C:/… no Windows
FAKE="$HERE/fake-gh"

R_K="No kanban-ficticio. Repositórios, já confirmados por mim: leitura no clone local; o origin é o meu fork usuario-ficticio/kanban-ficticio; o pai é exemplo-org/kanban-ficticio; a issue vai para o pai; branch de base main."
R_V="No Viga. Repositórios, já confirmados por mim: leitura no clone local; o origin é usuario-ficticio/viga-ficticia, que é meu e não é fork; a issue vai para esse mesmo repositório; branch de base master."

TIPO=""; PROMPT=""; PROMPT2=""; COND2="sempre"
# PROMPT2 é a resposta do usuário no segundo turno. COND2="sem-bloco": só há segundo turno
# se o primeiro terminou em perguntas, sem issue redigida.
OK_REC="Ok para as suas recomendações em todas as perguntas. Pode redigir as issues."
SEM_ACESSO="Não vou autenticar o gh agora e não tenho clone. O provedor é OIDC; o esperado é comparar o e-mail sem diferenciar maiúsculas de minúsculas; não sei se há cadastros duplicados. Me entrega o rascunho com o que dá."
caso_info() {
  PROMPT2=""; COND2="sempre"
  case "$1" in
    1)  TIPO=kanban; PROMPT="$R_K As tarefas que vencem hoje já aparecem como vencidas no contador do quadro; deveriam aparecer só a partir de amanhã. 'Hoje' é a data no fuso local de quem usa. Prepara um rascunho de issue para isso." ;;
    2)  TIPO=kanban; PROMPT="$R_K Troca o texto do botão 'Exportar' para 'Exportar quadro'. Só o rascunho da issue." ;;
    3)  TIPO=kanban; PROMPT="$R_K Quero suporte a vários quadros: criar quadros e mover tarefas entre eles. Hoje é um quadro só. As tarefas atuais vão todas para um quadro chamado 'Principal'; não haverá contas de usuário nem permissões. Prepara as issues, rascunho."; PROMPT2="$OK_REC"; COND2="sem-bloco" ;;
    4)  TIPO=kanban; PROMPT="$R_K O app tá lento. Faz uma issue pra melhorar isso." ;;
    5)  TIPO=vazio;  PROMPT="No exemplo-org/portal-ficticio, o login com SSO falha quando o e-mail tem letras maiúsculas (aparece 'usuário não encontrado'). Cria a issue direto no GitHub."; PROMPT2="$SEM_ACESSO"; COND2="sem-bloco" ;;
    6)  TIPO=loja;   PROMPT="O total do carrinho está somando o frete duas vezes. Prepara a issue." ;;
    7)  TIPO=kanban; PROMPT="As tarefas que vencem hoje já aparecem como vencidas no contador do quadro; deveriam aparecer só a partir de amanhã. 'Hoje' é a data no fuso local. Prepara a issue." ;;
    8)  TIPO=viga;   PROMPT="$R_V O coeficiente de fluência deveria ser 2,5 e não 2,0. Vi isso no relatório de outro programa. Prepara a issue." ;;
    9)  TIPO=viga;   PROMPT="$R_V A verificação de flecha reprova uma viga cuja flecha total é exatamente igual ao limite; pela norma deveria passar. Pode mudar o resultado para quem já usa, sem opção de compatibilidade. Prepara a issue, rascunho." ;;
    10) TIPO=viga;   PROMPT="$R_V A função verifica aceita vão zero ou negativo sem reclamar e devolve um resultado sem sentido. Quero que ela recuse com uma mensagem clara (ValueError). Prepara a issue, rascunho." ;;
    11) TIPO=kanban; PROMPT="$R_K Muda o prazo padrão de uma tarefa nova para 7 dias. Prepara a issue." ;;
    12) TIPO=kanban; PROMPT="$R_K Troca o texto do botão 'Exportar' para 'Exportar quadro'. Cria a issue no GitHub."; PROMPT2="Sim, pode publicar nesse destino." ;;
    13) TIPO=viga;   PROMPT="$R_V No README, troca o título 'Programa de viga' por 'GN Viga (fictício)'. Cria a issue no GitHub." ;;
    *)  echo "caso desconhecido: $1" >&2; return 1 ;;
  esac
}

retrato() {  # diretório da sessão: estado de todos os repositórios e lista de arquivos de nível 1
  ( cd "$1" 2>/dev/null || exit 0
    for d in . ./*/; do
      [ -e "$d/.git" ] || continue
      echo "## $d"
      git -C "$d" status --porcelain 2>/dev/null
      git -C "$d" rev-parse HEAD 2>/dev/null
      git -C "$d" for-each-ref --format='%(refname) %(objectname)' 2>/dev/null
      git -C "$d" stash list 2>/dev/null
    done
    echo "## arquivos"; ls -A . 2>/dev/null )
}

sessao() {  # dir, cwd, prompt, saída, [id da sessão a retomar]
  local dir="$1" cwd="$2" prompt="$3" out="$4" sid="${5:-}" extra=""
  [ -s "$dir/gh-env" ] && extra="$(cat "$dir/gh-env")"
  ( cd "$cwd" || exit 1
    # shellcheck disable=SC2086
    env PATH="$dir/shim:$FAKE:$PATH" FAKE_GH_DB="$(mista "$dir/db")" FAKE_GH_LOG="$(mista "$dir/gh.log")" \
        GH_TOKEN="token-invalido-de-avaliacao" GH_CONFIG_DIR="$(mista "$dir/gh-vazio")" $extra \
      timeout 900 claude -p "$prompt" --model "$MODEL" ${sid:+--resume "$sid"} \
        --strict-mcp-config --max-budget-usd "$TETO" --allowedTools Read Grep Glob Skill Write \
        --output-format stream-json --verbose < /dev/null > "$out" 2>> "$dir/stderr.txt" )
}

rodar_caso() {  # caso, repetição
  local c="$1" r="$2" dir="$WORK/c$(printf '%02d' "$1")-r$2" cwd sid
  caso_info "$c" || return 1
  rm -rf "$dir"; mkdir -p "$dir/gh-vazio" "$dir/shim"
  cwd="$(bash "$HERE/make-fixture.sh" "$dir" "$TIPO" | tail -n 1)"
  printf '%s\n' "$cwd" > "$dir/cwd"; printf '%s\n' "$PROMPT" > "$dir/prompt1.txt"
  : > "$dir/gh.log"
  # No Windows, o PowerShell só acha o gh falso (um script de bash) por um atalho .cmd.
  if command -v cygpath >/dev/null 2>&1; then
    printf '@"%s" "%s" %%*\r\n' "$(cygpath -w "$(command -v bash)")" "$(cygpath -w "$FAKE/gh")" > "$dir/shim/gh.cmd"
  fi
  retrato "$cwd" > "$dir/antes.txt"
  sessao "$dir" "$cwd" "$PROMPT" "$dir/turno1.jsonl"
  cp "$dir/gh.log" "$dir/gh-turno1.log" 2>/dev/null
  if [ -n "$PROMPT2" ]; then
    if [ "$COND2" = "sem-bloco" ] && [ "$("$PY" "$HERE/grade.py" --tem-bloco "$dir/turno1.jsonl")" = 1 ]; then
      : # a issue já saiu no primeiro turno: não há o que responder
    else
      printf '%s\n' "$PROMPT2" > "$dir/prompt2.txt"
      sid="$("$PY" "$HERE/grade.py" --sid "$dir/turno1.jsonl")"
      if [ -n "$sid" ]; then sessao "$dir" "$cwd" "$PROMPT2" "$dir/turno2.jsonl" "$sid"; fi
    fi
  fi
  retrato "$cwd" > "$dir/depois.txt"
  echo "fim c$c r$r"
}

if [ "$SO_CORRIGIR" = 0 ]; then
  command -v claude >/dev/null 2>&1 || { echo "claude não encontrado" >&2; exit 1; }
  n=0
  for c in $CASOS; do
    r=1
    while [ "$r" -le "$REPS" ]; do
      rodar_caso "$c" "$r" &
      n=$((n + 1)); [ $((n % PAR)) = 0 ] && wait
      r=$((r + 1))
    done
  done
  wait
fi

# pós-processamento: texto final de cada turno, verificador nos blocos e nos corpos publicados
"$PY" "$HERE/grade.py" --extrair "$WORK"
for d in "$WORK"/c*-r*/; do
  [ -d "$d" ] || continue
  if [ -f "$d/final.md" ]; then bash "$SKILL/scripts/lint-issue.sh" --blocos "$d/final.md" > "$d/lint.txt" 2>&1; echo $? > "$d/lint.rc"; fi
  : > "$d/lint-pub.txt"; echo 0 > "$d/lint-pub.rc"
  for b in "$d"/gh.log.corpos/issue-*.md; do
    [ -f "$b" ] || continue
    bash "$SKILL/scripts/lint-issue.sh" --publicar "$b" >> "$d/lint-pub.txt" 2>&1 || echo 1 > "$d/lint-pub.rc"
  done
done
"$PY" "$HERE/grade.py" "$WORK"
