#!/usr/bin/env bash
# Testes de scripts/lint-issue.sh. Sem rede.
# Uso: bash evals/test-lint-issue.sh      (sai com 1 se algum caso falhar)
set -u
HERE="$(cd "$(dirname "$0")" && pwd -P)"
L="$(cd "$HERE/.." && pwd -P)/scripts/lint-issue.sh"
W="$(mktemp -d)"; trap 'rm -rf "$W"' EXIT
PASS=0; FAIL=0; OUT=""; RC=0
ok()    { PASS=$((PASS + 1)); printf 'ok     %s\n' "$1"; }
bad()   { FAIL=$((FAIL + 1)); printf 'FALHA  %s\n         %s\n' "$1" "$2"; }
roda()  { OUT="$(bash "$L" "$@" 2>&1)"; RC=$?; }
t_rc()  { if [ "$RC" = "$2" ]; then ok "$1"; else bad "$1" "código $RC, esperado $2. Saída: $(printf '%s' "$OUT" | head -n 4 | tr '\n' '|')"; fi; }
t_has() { case "$OUT" in *"$2"*) ok "$1" ;; *) bad "$1" "faltou: $2" ;; esac; }
t_not() { case "$OUT" in *"$2"*) bad "$1" "não deveria conter: $2" ;; *) ok "$1" ;; esac; }

boa_m() {  # corpo de uma issue M correta (sem o título)
  cat <<'EOF'
**Resultado esperado:** uma tarefa só conta como vencida a partir do dia seguinte ao vencimento.
**Tipo:** correção

_Marcadores: [verificado] foi conferido no repositório; [hipótese] ainda não._

## Problema e impacto
O contador inclui tarefas que vencem hoje. Ver https://github.com/exemplo-org/kanban-ficticio/issues/7.

## Escopo
**Dentro:** regra de vencimento.
**Fora do escopo:** formato da data.

## Critérios de aceite
- [ ] CA1 Tarefa que vence hoje não é vencida.

## Plano de validação
| Critério | Checagem | Tipo |
|---|---|---|
| CA1 | `npm test` [verificado em `AGENTS.md`, não executado] | automática |

## Ambiente necessário
Node 20 ou mais recente [verificado em `AGENTS.md`].

## Pare e pergunte se
- for preciso mudar a assinatura de `isOverdue`.

## Dependências, decisões pendentes e bloqueios
- Suposições adotadas: nenhuma

<details>
<summary>Para o agente que for executar</summary>

**Controle:** Status: PRONTA · Tamanho: M · Cálculo/norma: não
**Verificação:** Lido em `exemplo-org/kanban-ficticio@main` `abc1234` (2026-11-11).

### Como executar
1. Leia esta issue inteira.

</details>
EOF
}

echo "== issue correta =="
boa_m > "$W/boa.md"
roda "$W/boa.md";               t_rc "M correta passa" 0; t_has "resumo sem erros" "0 erro(s)"
roda --publicar "$W/boa.md";    t_rc "M correta passa com --publicar" 0
t_not "URL https não é tratada como caminho absoluto" "caminho absoluto"

echo "== cada defeito é apontado =="
defeito() {  # nome, expressão sed, trecho esperado na saída
  sed -e "$2" "$W/boa.md" > "$W/ruim.md"; roda "$W/ruim.md"
  if [ "$RC" = 1 ]; then ok "$1: reprova"; else bad "$1: reprova" "código $RC"; fi
  t_has "$1: mensagem" "$3"
}
defeito "status fora do padrão"      's/Status: PRONTA/Status: ÉPICO/'                   "Status fora dos dois valores"
defeito "status inventado"           's/Status: PRONTA/Status: RASCUNHO PRONTO/'         "Status fora dos dois valores"
defeito "sem tamanho"                's/ · Tamanho: M//'                                 "falta 'Tamanho: P|M|G'"
defeito "sem cálculo/norma"          's/ · Cálculo\/norma: não//'                        "falta 'Cálculo/norma"
defeito "sem suposições"             's/- Suposições adotadas: nenhuma/- nada/'          "Suposições adotadas:"
defeito "sem fora do escopo"         's/\*\*Fora do escopo:\*\* formato da data\.//'     "Fora do escopo"
defeito "sem ambiente"               's/## Ambiente necessário/## Ambiente/'             "Ambiente necessário"
defeito "sem pare e pergunte"        's/## Pare e pergunte se/## Paradas/'               "Pare e pergunte se"
defeito "sem como executar"          's/### Como executar/### Passos/'                   "Como executar"
defeito "sem verificação"            's/Lido em/Visto em/'                               "linha de verificação"
defeito "sem critério em caixa"      's/- \[ \] CA1/- CA1/'                              "caixa de seleção"
defeito "número de issue não trocado" 's#issues/7#issues/\#<N>#'                         "#<"
defeito "resto de preenchimento"     's/Node 20 ou mais recente/<comando de teste>/'     "resto de preenchimento"
defeito "ver abaixo"                 's/1\. Leia esta issue inteira\./(ver abaixo)/'     "ver abaixo"
defeito "arquivo da skill"           's/1\. Leia esta issue inteira\./Conforme model-map.yaml./' "arquivo da skill"
defeito "caminho do Windows"         's#regra de vencimento\.#regra em C:\\GNApp\\kanban\\src.#' "caminho absoluto"
defeito "caminho do Git Bash"        's#regra de vencimento\.#regra em /c/GNApp/kanban.#' "caminho absoluto"
defeito "caminho da pasta pessoal"   's#regra de vencimento\.#regra em ~/projetos/kanban.#' "caminho absoluto"
defeito "código de perfil"           's/Tamanho: M ·/Tamanho: M · Perfil: C2 ·/'         "código de perfil"

echo "== cálculo, bloqueio, issue-mãe, P =="
sed -e 's/Cálculo\/norma: não/Cálculo\/norma: sim/' "$W/boa.md" > "$W/calc.md"; roda "$W/calc.md"
t_rc "cálculo sem fórmulas reprova" 1; t_has "pede fórmulas" "Fórmulas, regras e fontes"; t_has "pede exemplo numérico" "Exemplo numérico"
cat > "$W/bloq.md" <<'EOF'
> **RASCUNHO BLOQUEADO: não atribuir a agente.**
> **Falta para ficar PRONTA:**
> 1. Qual operação está lenta.

**Resultado esperado:** (a definir)
**Tipo:** melhoria

<details>
<summary>Para o agente que for executar</summary>

**Controle:** Status: RASCUNHO BLOQUEADO · Tamanho: a definir · Cálculo/norma: não
Não execute: a issue está bloqueada.

</details>
EOF
roda "$W/bloq.md"; t_rc "bloqueada mínima passa" 0
sed -e '/Falta para ficar PRONTA/d' "$W/bloq.md" > "$W/bloq2.md"; roda "$W/bloq2.md"
t_rc "bloqueada sem a lista reprova" 1; t_has "pede a lista do que falta" "Falta para ficar PRONTA:"
sed -e 's/Tamanho: M/Tamanho: G (issue-mãe)/' "$W/boa.md" > "$W/mae.md"; roda "$W/mae.md"
t_rc "mãe sem plano de sub-issues reprova" 1; t_has "pede o plano de sub-issues" "Plano de sub-issues"
{ sed -e 's/Tamanho: M/Tamanho: P/' "$W/boa.md"; i=0; while [ $i -lt 400 ]; do printf 'palavra '; i=$((i + 1)); done; echo; } > "$W/p.md"
roda "$W/p.md"; t_rc "P longa só avisa" 0; t_has "aviso de tamanho em P" "AVISO"

echo "== blocos e publicação =="
{ echo 'Status: PRONTA · Tamanho: M'; echo; echo '````markdown'; echo '# Não marcar como vencida a tarefa de hoje'; echo; boa_m; echo '````'; echo; echo 'Verificador: sem pendências.'; } > "$W/resp.md"
roda --blocos "$W/resp.md"; t_rc "resposta com um bloco passa" 0
{ cat "$W/resp.md"; echo '````markdown'; echo 'sem título'; boa_m | sed 's/Status: PRONTA/Status: FEITA/'; echo '````'; } > "$W/resp2.md"
roda --blocos "$W/resp2.md"; t_rc "segundo bloco ruim reprova" 1; t_has "aponta o bloco" "bloco 2 de 2"; t_has "bloco sem título" "deve começar com a linha '# <título>'"
echo "sem blocos" > "$W/nada.md"; roda --blocos "$W/nada.md"; t_rc "sem blocos reprova" 1
{ echo '# Título no corpo'; boa_m; } > "$W/pub.md"; roda --publicar "$W/pub.md"
t_rc "título no corpo reprova na publicação" 1; t_has "explica o título" "--title"
printf 'a\r\n' > "$W/crlf.md"; boa_m | sed 's/$/\r/' >> "$W/crlf.md"; roda "$W/crlf.md"; t_rc "arquivo com CRLF é aceito" 0
roda; t_rc "sem argumento sai com 2" 2

echo
echo "Resultado: $PASS ok, $FAIL falha(s)"
[ "$FAIL" = 0 ]
