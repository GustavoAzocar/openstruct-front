#!/usr/bin/env bash
# Testes de scripts/repo-context.sh com repositórios locais descartáveis e o gh falso.
# Não usa rede e não toca em nenhum repositório real.
#
# Uso: bash evals/test-repo-context.sh      (sai com 1 se algum caso falhar)
#      KEEP=1 bash evals/test-repo-context.sh   mantém o diretório de trabalho
set -u
HERE="$(cd "$(dirname "$0")" && pwd -P)"
SKILL="$(cd "$HERE/.." && pwd -P)"
S="$SKILL/scripts/repo-context.sh"
FAKE="$HERE/fake-gh"
W="$(mktemp -d)"
[ "${KEEP:-0}" = 1 ] || trap 'rm -rf "$W"' EXIT

PASS=0; FAIL=0; OUT=""; RC=0
ok()    { PASS=$((PASS + 1)); printf 'ok     %s\n' "$1"; }
bad()   { FAIL=$((FAIL + 1)); printf 'FALHA  %s\n         %s\n' "$1" "$2"; }
has()   { case "$1" in *"$2"*) return 0 ;; *) return 1 ;; esac; }
t_has() { if has "$OUT" "$2"; then ok "$1"; else bad "$1" "faltou: $2"; fi; }
t_not() { if has "$OUT" "$2"; then bad "$1" "não deveria conter: $2"; else ok "$1"; fi; }
t_rc()  { if [ "$RC" = "$2" ]; then ok "$1"; else bad "$1" "código de saída $RC, esperado $2"; fi; }
g()     { git -c user.email=fict@example.invalid -c user.name=Ficticio -c commit.gpgsign=false -c core.autocrlf=false "$@"; }
have()  { command -v "$1" >/dev/null 2>&1; }

DB=""; LOG=""
novo_db() { DB="$W/db-$1"; LOG="$W/log-$1"; rm -rf "$DB" "$LOG" "$LOG.corpos"; mkdir -p "$DB/repo" "$DB/sha" "$DB/issues" "$DB/labels"; : > "$LOG"; }
chave()   { printf '%s' "$1" | sed 's#/#__#g'; }
db_repo() {  # slug fork pai padrao issues permissao privado organizacao [templates]
  local vis="PUBLIC"; [ "$7" = true ] && vis="PRIVATE"
  cat > "$DB/repo/$(chave "$1")" <<EOF
slug=$1
fork=$2
pai=$3
padrao=$4
issues=$5
permissao=$6
privado=$7
arquivado=false
visibilidade=$vis
organizacao=$8
templates=${9:-}
EOF
}
run_fake() { OUT="$(PATH="$FAKE:$PATH" FAKE_GH_DB="$DB" FAKE_GH_LOG="$LOG" bash "$S" "$@" 2>&1)"; RC=$?; }
run_off()  { OUT="$(bash "$S" "$@" --offline 2>&1)"; RC=$?; }

mk_fork() {  # diretório: origin = fork do usuário; upstream = pai; main 1 à frente e 2 atrás do pai
  mkdir -p "$1/src/sub" && cd "$1" || return 1
  git init -q -b main
  echo "console.log(1)" > src/a.js; echo "x" > src/sub/b.js
  printf '# Fixture\n' > README.md; printf '# Agentes\n' > AGENTS.md
  g add -A && g commit -qm "base"
  g commit -q --allow-empty -m "ajuste local do fork"
  git remote add origin https://github.com/usuario-ficticio/kanban-ficticio.git
  git remote add upstream https://github.com/exemplo-org/kanban-ficticio.git
  git config remote.upstream.gh-resolved base
  git update-ref refs/remotes/origin/main HEAD
  git checkout -q -b tmp HEAD~1
  g commit -q --allow-empty -m "upstream 1"; g commit -q --allow-empty -m "upstream 2"
  git update-ref refs/remotes/upstream/main HEAD
  git checkout -q main && git branch -q -D tmp
}

echo "== 1. formas de URL, credenciais e hosts =="
R="$W/urls"; mkdir -p "$R" && cd "$R" && git init -q -b main && g commit -q --allow-empty -m base
git remote add origin https://github.com/dono-a/repo-a.git
git remote add r2 https://github.com/dono-a/repo-a
git remote add r3 git@github.com:dono-a/repo-a.git
git remote add r4 ssh://git@github.com/dono-a/repo-a
git remote add r5 https://usuario:ghp_SEGREDO123@github.com/dono-a/repo-a.git
git remote add r6 https://gitlab.com/grupo/sub/projeto.git
git remote add r7 https://github.com/a/b/c
git remote add r8 ../outro-repo
run_off "$R"
n="$(printf '%s\n' "$OUT" | grep -c '→  dono-a/repo-a$')"
if [ "$n" = 5 ]; then ok "5 formas de URL dão o mesmo slug"; else bad "5 formas de URL dão o mesmo slug" "obtidas $n"; fi
t_not "token da URL não aparece na saída" "ghp_SEGREDO123"
t_has "host que não é GitHub é avisado" "não é github.com"
t_has "caminho com três segmentos é avisado" "mais de dois segmentos"
t_has "caminho local não tem slug" "sem slug"
t_has "offline não consulta o gh" "não consultado (--offline)"
t_rc  "sai com 0" 0

echo "== 2. fork com upstream e gh-resolved=base =="
R="$W/fork"; mk_fork "$R"
novo_db fork; echo "usuario-ficticio" > "$DB/user"
db_repo usuario-ficticio/kanban-ficticio true exemplo-org/kanban-ficticio main false ADMIN false false
db_repo exemplo-org/kanban-ficticio false "" main true READ false true "Bug [título: [Bug] ]"
git -C "$R" rev-parse refs/remotes/upstream/main > "$DB/sha/exemplo-org__kanban-ficticio__main"
echo "  #7 [OPEN] [Bug] Exemplo de issue  {bug}" > "$DB/issues/exemplo-org__kanban-ficticio"
echo "bug, enhancement" > "$DB/labels/exemplo-org__kanban-ficticio"
run_fake "$R"
t_has "origin é reconhecido como fork" "origin usuario-ficticio/kanban-ficticio: fork=sim · pai=exemplo-org/kanban-ficticio"
t_has "pai é consultado" "pai exemplo-org/kanban-ficticio: fork=não"
t_has "destino sugerido é o pai" "destino sugerido da issue: exemplo-org/kanban-ficticio"
t_has "destino não é do usuário" "destino é do usuário autenticado: não"
t_has "pede confirmação extra" "confirmação extra ao publicar: sim"
t_has "template com prefixo de título" "[título: [Bug] ]"
t_has "aviso de permissão READ" "Permissão READ em exemplo-org/kanban-ficticio"
t_has "à frente e atrás do pai" "HEAD está 1 à frente e 2 atrás de upstream/main"
t_has "commit lido não contido no padrão" "commit lido contido no padrão: não"
t_has "ref local atual" "ref local upstream/main: atual"
t_has "lista issues do destino" "#7 [OPEN] [Bug] Exemplo de issue"
t_has "tipo de issue em organização" "pode existir (organização)"
t_has "linha de verificação" "Lido em usuario-ficticio/kanban-ficticio@main"
if grep -q VIOLACAO "$LOG"; then bad "nenhuma chamada sem slug" "$(grep VIOLACAO "$LOG" | head -n 1)"; else ok "nenhuma chamada sem slug"; fi
if grep -E '^gh repo view' "$LOG" | grep -v -q -E '^gh repo view [A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+ '; then
  bad "todo repo view tem slug explícito" "$(grep -E '^gh repo view' "$LOG" | head -n 2)"
else ok "todo repo view tem slug explícito"; fi

echo "== 3. ref local defasada =="
echo "0000000000000000000000000000000000000000" > "$DB/sha/exemplo-org__kanban-ficticio__main"
run_fake "$R"
t_has "detecta ref local defasada" "DEFASADA"

echo "== 4. branch de feature enviado só ao fork; commit não enviado; árvore suja =="
git -C "$R" checkout -q -b feat/x && ( cd "$R" && g commit -q --allow-empty -m "feature" )
git -C "$R" update-ref refs/remotes/origin/feat/x HEAD
run_off "$R"
t_has "feature enviada ao fork" "commit lido já enviado: sim (origin/feat/x)"
( cd "$R" && g commit -q --allow-empty -m "local" )
run_off "$R"
t_has "commit não enviado é avisado" "não está em nenhum branch remoto conhecido"
echo "mudou" >> "$R/src/a.js"; echo "novo" > "$R/novo.txt"
run_off "$R"
t_has "árvore suja é contada" "1 arquivo(s) rastreado(s) modificado(s), 1 não rastreado(s)"
t_has "árvore suja gera aviso" "o executor não verá essas alterações"
git -C "$R" checkout -q -- src/a.js; rm -f "$R/novo.txt"

echo "== 5. origin de terceiro (READ) e repositório do usuário =="
R3="$W/terceiro"; mkdir -p "$R3" && cd "$R3" && git init -q -b master && g commit -q --allow-empty -m base
git remote add origin https://github.com/terceiro/projeto.git
git update-ref refs/remotes/origin/master HEAD
novo_db terceiro; echo "usuario-ficticio" > "$DB/user"
db_repo terceiro/projeto false "" master true READ false false
run_fake "$R3"
t_has "destino é o origin de terceiro" "destino sugerido da issue: terceiro/projeto"
t_has "terceiro não é do usuário" "destino é do usuário autenticado: não"
t_has "terceiro pede confirmação" "confirmação extra ao publicar: sim"
t_has "branch padrão master" "branch padrão de referência: master"
t_has "conta pessoal sem tipo de issue" "não use --type"
RP="$W/proprio"; mkdir -p "$RP" && cd "$RP" && git init -q -b main && g commit -q --allow-empty -m base
git remote add origin git@github.com:Usuario-Ficticio/meu.git
novo_db proprio; echo "usuario-ficticio" > "$DB/user"
db_repo Usuario-Ficticio/meu false "" main true ADMIN true false
run_fake "$RP"
t_has "repositório do usuário (sem diferenciar maiúsculas)" "destino é do usuário autenticado: sim"
t_has "sem confirmação extra no próprio" "confirmação extra ao publicar: não"
t_not "privado não gera aviso de público" "é público"

echo "== 6. issues desligadas, fork e pai com issues, 404 =="
novo_db semissues; echo "usuario-ficticio" > "$DB/user"
db_repo Usuario-Ficticio/meu false "" main false ADMIN true false
run_fake "$RP"
t_has "issues desligadas: sem destino" "destino sugerido da issue: nenhum: issues desligadas no origin"
novo_db ambos; echo "usuario-ficticio" > "$DB/user"
db_repo usuario-ficticio/kanban-ficticio true exemplo-org/kanban-ficticio main true ADMIN false false
db_repo exemplo-org/kanban-ficticio false "" main true READ false true
run_fake "$R"
t_has "fork e pai com issues: perguntar" "destino sugerido da issue: nenhum: fork e pai têm issues ligadas"
novo_db vazio; echo "usuario-ficticio" > "$DB/user"
run_fake "$RP"
t_has "404 é reconhecido" "inexistente ou inacessível"
t_has "404 gera aviso de não publicar" "não há como publicar"

echo "== 7. gh ausente, sem autenticação, lento =="
semgh=""; oldifs="$IFS"; IFS=:
for p in $PATH; do
  if [ -x "$p/gh" ] || [ -x "$p/gh.exe" ] || [ -f "$p/gh.cmd" ]; then continue; fi
  semgh="${semgh}${semgh:+:}$p"
done
IFS="$oldifs"
OUT="$(PATH="$semgh" bash "$S" "$RP" 2>&1)"; RC=$?
t_has "gh ausente é informado" "gh: ausente"
t_rc  "gh ausente sai com 0" 0
novo_db noauth
OUT="$(PATH="$FAKE:$PATH" FAKE_GH_DB="$DB" FAKE_GH_LOG="$LOG" FAKE_GH_AUTH=none bash "$S" "$RP" 2>&1)"; RC=$?
t_has "sem autenticação é informado" "gh autenticado: não"
t_has "sem autenticação não confirma fork" "fork: não confirmado"
if have timeout && timeout --version 2>/dev/null | grep -qi coreutils; then
  novo_db lento; echo "usuario-ficticio" > "$DB/user"
  SECONDS=0
  OUT="$(PATH="$FAKE:$PATH" FAKE_GH_DB="$DB" FAKE_GH_LOG="$LOG" FAKE_GH_SLOW=4 OPENSTRUCT_GH_TIMEOUT=1 bash "$S" "$RP" 2>&1)"; RC=$?
  t_has "gh lento: tempo esgotado" "sem resposta em 1s"
  if [ "$SECONDS" -lt 20 ]; then ok "gh lento: tempo total limitado (${SECONDS}s)"; else bad "gh lento: tempo total limitado" "${SECONDS}s"; fi
else
  echo "pulado  gh lento (sem timeout do coreutils)"
fi

echo "== 8. espaço de trabalho, pastas com espaço, subpasta =="
E="$W/espaco de trabalho"; mkdir -p "$E/Repo Um" "$E/repo-dois" "$E/pasta sem git"
( cd "$E/Repo Um" && git init -q -b main && g commit -q --allow-empty -m base && git remote add origin https://github.com/dono-a/Repo-Um.git )
( cd "$E/repo-dois" && git init -q -b master && g commit -q --allow-empty -m base && git remote add origin https://github.com/dono-a/repo-dois.git && git remote add upstream https://github.com/outro/repo-dois.git )
novo_db espaco; echo "usuario-ficticio" > "$DB/user"
run_fake "$E"
t_has "modo espaço de trabalho" "modo: espaço de trabalho"
t_has "lista repositório com espaço no nome" "Repo Um  →  dono-a/Repo-Um  ·  branch main"
t_has "lista segundo repositório e o upstream" "repo-dois  →  dono-a/repo-dois  ·  branch master · tem remote upstream"
t_has "pasta sem git fica à parte" "subpastas sem git: pasta sem git"
t_has "pede para perguntar o alvo" "Pergunte ao usuário qual é o repositório"
if grep -q -E '^gh repo view' "$LOG"; then bad "espaço de trabalho não consulta repositórios" "houve repo view"; else ok "espaço de trabalho não consulta repositórios"; fi
run_off "$E/Repo Um"
t_has "argumento com espaço funciona" "Repo Um"
t_has "argumento com espaço acha o slug" "→  dono-a/Repo-Um"
run_off "$W/fork/src/sub"
t_has "subpasta acha a raiz" "$(cd "$W/fork" && git rev-parse --show-toplevel)"

echo "== 9. HEAD destacado, repositório sem commits, sem remotes =="
git -C "$RP" checkout -q --detach
run_off "$RP"; t_has "HEAD destacado" "(HEAD destacado)"; t_rc "HEAD destacado sai com 0" 0
git -C "$RP" checkout -q main
V="$W/vazio"; mkdir -p "$V" && ( cd "$V" && git init -q -b main )
run_off "$V"; t_has "repositório sem commits" "repositório sem commits"; t_has "sem remotes" "(nenhum remote)"; t_rc "sem commits sai com 0" 0

echo "== 10. somente leitura =="
if have sha1sum; then SUM=sha1sum; elif have shasum; then SUM=shasum; else SUM=""; fi
if [ -n "$SUM" ]; then
  soma() { ( cd "$1" && find .git -type f | LC_ALL=C sort | while IFS= read -r f; do $SUM "$f"; done | $SUM | cut -d' ' -f1 ); }
  antes="$(soma "$W/fork")"; st_antes="$(git -C "$W/fork" status --porcelain)"
  novo_db leitura; echo "usuario-ficticio" > "$DB/user"
  db_repo usuario-ficticio/kanban-ficticio true exemplo-org/kanban-ficticio main false ADMIN false false
  db_repo exemplo-org/kanban-ficticio false "" main true READ false true
  run_fake "$W/fork"
  depois="$(soma "$W/fork")"; st_depois="$(git -C "$W/fork" status --porcelain)"
  if [ "$antes" = "$depois" ] && [ "$st_antes" = "$st_depois" ]; then ok ".git e git status idênticos antes e depois"; else bad ".git e git status idênticos antes e depois" "mudou"; fi
else
  echo "pulado  somente leitura (sem sha1sum)"
fi

echo "== 11. ajuda, opção desconhecida e checagens estáticas =="
OUT="$(bash "$S" --help 2>&1)"; RC=$?
t_rc "--help sai com 0" 0; t_has "--help mostra o uso" "Uso: bash repo-context.sh"; t_not "--help não vaza código" "set -u"
OUT="$(bash "$S" --nao-existe 2>&1)"; RC=$?; t_rc "opção desconhecida sai com 2" 2
if [ "$(tr -cd '\r' < "$S" | wc -c | tr -d ' ')" = 0 ]; then ok "script sem CR"; else bad "script sem CR" "há CR"; fi
if grep -n -E 'declare -A|mapfile|readarray|\$\{[A-Za-z_]+(,,|\^\^)|&>>' "$S" >/dev/null; then
  bad "sem recursos de bash 4" "$(grep -n -E 'declare -A|mapfile|readarray|\$\{[A-Za-z_]+(,,|\^\^)|&>>' "$S" | head -n 2)"
else ok "sem recursos de bash 4"; fi
if grep -n -E 'git (fetch|pull|push|commit|checkout|reset|merge|rebase|add|stash|clean|gc)( |$)' "$S" | grep -v -E '^[0-9]+:[[:space:]]*#|warn |say |kv ' >/dev/null; then
  bad "script não chama comandos git de escrita" "$(grep -n -E 'git (fetch|pull|push|commit|checkout|reset|merge|rebase|add|stash|clean|gc)( |$)' "$S" | grep -v -E '^[0-9]+:[[:space:]]*#|warn |say |kv ' | head -n 2)"
else ok "script não chama comandos git de escrita"; fi

echo
echo "Resultado: $PASS ok, $FAIL falha(s)"
[ "$FAIL" = 0 ]
