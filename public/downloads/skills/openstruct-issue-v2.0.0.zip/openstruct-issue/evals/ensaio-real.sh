#!/usr/bin/env bash
# Ensaio da skill openstruct-issue num repositório REAL, só em rascunho.
# Abre uma sessão nova do Claude Code (claude -p) na pasta indicada, com o gh SOMENTE LEITURA
# de gh-somente-leitura/ (nenhuma issue pode ser criada), e confere que nada mudou no repositório.
#
# Uso: bash evals/ensaio-real.sh <dir-de-trabalho> <nome> <pasta> "<pedido>" [modelo]
#   <pasta> pode ser um repositório ou uma pasta com vários repositórios.
# Saída em <dir-de-trabalho>/<nome>/: final.md (resposta), lint.txt, gh.log, antes.txt, depois.txt.
set -u
WORK="${1:?diretório de trabalho}"; NOME="${2:?nome}"; ALVO="${3:?pasta}"; PEDIDO="${4:?pedido}"; MODEL="${5:-sonnet}"
HERE="$(cd "$(dirname "$0")" && pwd -P)"; SKILL="$(cd "$HERE/.." && pwd -P)"
PY="$(command -v python3 || command -v python)" || { echo "python não encontrado" >&2; exit 1; }
mista() { if command -v cygpath >/dev/null 2>&1; then cygpath -m "$1"; else printf '%s' "$1"; fi; }
REAL="$(command -v gh)" || { echo "gh não encontrado" >&2; exit 1; }
RO="$HERE/gh-somente-leitura"
dir="$WORK/$NOME"; rm -rf "$dir"; mkdir -p "$dir/shim"; dir="$(cd "$dir" && pwd -P)"
ALVO="$(cd "$ALVO" && pwd -P)" || exit 1
if command -v cygpath >/dev/null 2>&1; then
  printf '@"%s" "%s" %%*\r\n' "$(cygpath -w "$(command -v bash)")" "$(cygpath -w "$RO/gh")" > "$dir/shim/gh.cmd"
fi

retrato() {
  ( cd "$1" || exit 0
    for d in . ./*/; do
      [ -e "$d/.git" ] || continue
      echo "## $d"
      git -C "$d" status --porcelain 2>/dev/null
      git -C "$d" rev-parse HEAD 2>/dev/null
      git -C "$d" for-each-ref --format='%(refname) %(objectname)' 2>/dev/null
      git -C "$d" stash list 2>/dev/null
    done )
}

printf '%s\n' "$PEDIDO" > "$dir/pedido.txt"; : > "$dir/gh.log"
retrato "$ALVO" > "$dir/antes.txt"
( cd "$ALVO" && env PATH="$dir/shim:$RO:$PATH" REAL_GH="$(mista "$REAL")" GH_RO_LOG="$(mista "$dir/gh.log")" \
    timeout 900 claude -p "$PEDIDO" --model "$MODEL" --strict-mcp-config --max-budget-usd 2.00 \
      --allowedTools Read Grep Glob Skill --disallowedTools Edit NotebookEdit \
      --output-format stream-json --verbose < /dev/null > "$dir/turno1.jsonl" 2> "$dir/stderr.txt" )
retrato "$ALVO" > "$dir/depois.txt"

"$PY" - "$dir" <<'EOF'
import io, json, sys
from pathlib import Path
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
d = Path(sys.argv[1]); final = ""; custo = 0.0; ferr = []
for linha in (d / "turno1.jsonl").read_text(encoding="utf-8", errors="replace").splitlines():
    try: ev = json.loads(linha)
    except Exception: continue
    if ev.get("type") == "assistant":
        for p in ev.get("message", {}).get("content", []) or []:
            if isinstance(p, dict) and p.get("type") == "tool_use":
                i = p.get("input") or {}
                ferr.append(f"{p.get('name')}: {str(i.get('command') or i.get('file_path') or i.get('skill') or i.get('pattern') or '')[:200]}")
    elif ev.get("type") == "result":
        final = ev.get("result") or ""; custo = ev.get("total_cost_usd") or 0.0
(d / "final.md").write_text(final, encoding="utf-8")
(d / "ferramentas.txt").write_text("\n".join(ferr), encoding="utf-8")
print(f"custo: US$ {custo:.2f} | chamadas de ferramenta: {len(ferr)}")
EOF

if grep -q '^````markdown' "$dir/final.md" 2>/dev/null; then bash "$SKILL/scripts/lint-issue.sh" --blocos "$dir/final.md" > "$dir/lint.txt" 2>&1; else echo "(sem bloco de issue na resposta)" > "$dir/lint.txt"; fi
if cmp -s "$dir/antes.txt" "$dir/depois.txt"; then echo "repositório: sem mudança"; else echo "repositório: MUDOU (compare antes.txt e depois.txt)"; fi
echo "gh bloqueado: $(grep -c '^BLOQUEADO' "$dir/gh.log")"; grep '^BLOQUEADO' "$dir/gh.log" | head -n 3
echo "verificador: $(tail -n 1 "$dir/lint.txt")"
echo "primeira linha da resposta: $(head -n 1 "$dir/final.md" | cut -c1-240)"
