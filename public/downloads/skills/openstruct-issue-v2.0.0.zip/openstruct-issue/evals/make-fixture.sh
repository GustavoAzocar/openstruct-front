#!/usr/bin/env bash
# Cria um repositório FICTÍCIO para a avaliação da skill openstruct-issue e o banco do gh falso.
# Nada aqui se refere a projeto, norma ou organização real.
#
# Uso: bash make-fixture.sh <destino> <tipo>
#   tipo: kanban   Node, fork (origin do usuário, upstream de terceiro), AGENTS.md, branch main
#         viga     Python de cálculo, só CLAUDE.md, branch master, pasta com espaço, norma fictícia
#         loja     pasta que NÃO é repositório, com dois repositórios dentro
#         vazio    pasta vazia, sem git; gh sem autenticação
# Imprime na última linha o diretório onde a sessão deve rodar.
# Cria também <destino>/db (respostas do gh falso) e <destino>/gh-env (variáveis extras).
set -eu
DEST="${1:?destino}"; TIPO="${2:?tipo}"
mkdir -p "$DEST"; DEST="$(cd "$DEST" && pwd -P)"
DB="$DEST/db"; mkdir -p "$DB/repo" "$DB/sha" "$DB/issues" "$DB/labels"
: > "$DEST/gh-env"
echo "usuario-ficticio" > "$DB/user"

g() { git -c user.email=fict@example.invalid -c user.name=Ficticio -c commit.gpgsign=false -c core.autocrlf=false "$@"; }
chave() { printf '%s' "$1" | sed 's#/#__#g'; }
db_repo() {  # slug fork pai padrao issues permissao privado organizacao [templates]
  local vis="PUBLIC"; [ "$7" = true ] && vis="PRIVATE"
  cat > "$DB/repo/$(chave "$1")" <<EOF
slug=$1
fork=$2
pai=$3
padrao=$4
issues=$5
permissao=$6
privado=$7
arquivado=false
visibilidade=$vis
organizacao=$8
templates=${9:-}
EOF
}
excluir_claude() { printf '.claude/\n' >> .git/info/exclude; }

case "$TIPO" in

kanban)
  R="$DEST/kanban-ficticio"; rm -rf "$R"; mkdir -p "$R"; cd "$R"
  mkdir -p src/tasks src/ui src/store/migrations src/api tests
  cat > README.md <<'EOF'
# kanban-ficticio

> REPOSITÓRIO FICTÍCIO, usado só na avaliação da skill openstruct-issue.

Quadro kanban mínimo em Node.js.
EOF
  cat > AGENTS.md <<'EOF'
# Instruções para agentes (repositório fictício)

- Node 20 ou mais recente. Sem dependências externas.
- Testes: `npm test` (usa `node --test`, que encontra `tests/*.test.js`).
- Todo bug corrigido ganha um teste em `tests/` que falha antes da correção.
- Não altere o formato de `data/tasks.json` sem migração em `src/store/migrations/`.
- Commits em português, no imperativo.
EOF
  printf '# Contribuindo (fictício)\nAbra uma issue antes do PR. PRs pequenos. Um PR por issue.\n' > CONTRIBUTING.md
  cat > package.json <<'EOF'
{ "name": "kanban-ficticio", "version": "0.3.0", "private": true,
  "scripts": { "test": "node --test" } }
EOF
  cat > src/tasks/overdue.js <<'EOF'
// Determina se uma tarefa está vencida.
// dueDate é uma string "AAAA-MM-DD" (data, sem hora).
function isOverdue(task, now = new Date()) {
  if (!task.dueDate || task.done) return false;
  const due = new Date(task.dueDate); // interpretado como meia-noite UTC
  return due <= now;
}

function listOverdue(tasks, now = new Date()) {
  return tasks.filter((t) => isOverdue(t, now));
}

module.exports = { isOverdue, listOverdue };
EOF
  cat > src/ui/export-button.js <<'EOF'
// Botão de exportação do quadro.
function renderExportButton(onClick) {
  return { tag: 'button', text: 'Exportar', onClick };
}
module.exports = { renderExportButton };
EOF
  cat > src/ui/board-view.js <<'EOF'
const { listOverdue } = require('../tasks/overdue');
const { renderExportButton } = require('./export-button');
function renderBoard(state) {
  return { columns: state.columns, overdueCount: listOverdue(state.tasks).length,
           toolbar: [renderExportButton(() => {})] };
}
module.exports = { renderBoard };
EOF
  cat > src/store/tasks-store.js <<'EOF'
// Armazena tarefas em data/tasks.json. Um único quadro implícito.
const fs = require('fs');
const FILE = process.env.TASKS_FILE || 'data/tasks.json';
function load() { try { return JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch { return { version: 1, tasks: [] }; } }
function save(data) { fs.writeFileSync(FILE, JSON.stringify(data, null, 2)); }
module.exports = { load, save };
EOF
  echo "// migrações de formato de dados (vazio)" > src/store/migrations/README.js
  cat > src/api/routes.js <<'EOF'
// Rotas HTTP mínimas: GET /tasks.
const store = require('../store/tasks-store');
function handle(req) {
  if (req.method === 'GET' && req.url === '/tasks') return { status: 200, body: store.load().tasks };
  return { status: 404 };
}
module.exports = { handle };
EOF
  cat > tests/overdue.test.js <<'EOF'
const test = require('node:test');
const assert = require('node:assert');
const { isOverdue } = require('../src/tasks/overdue');
test('tarefa concluída nunca está vencida', () => {
  assert.strictEqual(isOverdue({ dueDate: '2020-01-01', done: true }), false);
});
test('tarefa de ontem está vencida', () => {
  assert.strictEqual(isOverdue({ dueDate: '2026-11-10' }, new Date('2026-11-11T12:00:00Z')), true);
});
EOF
  git init -q -b main && g add -A && g commit -qm "Versão inicial (fictícia)"
  git remote add origin https://github.com/usuario-ficticio/kanban-ficticio.git
  git remote add upstream https://github.com/exemplo-org/kanban-ficticio.git
  git config remote.upstream.gh-resolved base
  # o fork e o pai estão no mesmo commit: o código lido é o do branch de base
  git update-ref refs/remotes/origin/main HEAD
  git update-ref refs/remotes/upstream/main HEAD
  excluir_claude
  db_repo usuario-ficticio/kanban-ficticio true exemplo-org/kanban-ficticio main false ADMIN false false
  db_repo exemplo-org/kanban-ficticio false "" main true READ false true
  git rev-parse HEAD > "$DB/sha/exemplo-org__kanban-ficticio__main"
  cat > "$DB/issues/exemplo-org__kanban-ficticio" <<'EOF'
  #41 [OPEN] Permitir arquivar colunas vazias
  #38 [CLOSED] Corrigir ordem das colunas ao recarregar o quadro  {bug}
  #35 [CLOSED] Mostrar a contagem de tarefas por coluna  {enhancement}
EOF
  echo "bug, documentation, enhancement, question" > "$DB/labels/exemplo-org__kanban-ficticio"
  echo "$R"
  ;;

viga)
  R="$DEST/Viga Ficticia"; rm -rf "$R"; mkdir -p "$R"; cd "$R"
  mkdir -p src/viga tests docs/normas
  cat > README.md <<'EOF'
# Programa de viga

> REPOSITÓRIO FICTÍCIO, usado só na avaliação da skill openstruct-issue. A norma "NF-200" não existe.

Verificação de flecha de vigas.
EOF
  cat > CLAUDE.md <<'EOF'
# Viga (repositório fictício)

- Python 3.12, Windows. Use sempre a venv do projeto, nunca `python` ou `pytest` direto.
- Testes: `.\.venv\Scripts\python.exe -m pytest -q`
- Toda mudança de critério de cálculo é registrada em `docs/DECISOES.md` **antes** do código.
- Não altere `tests/test_referencia.py`: é o teste de referência, conferido à mão.
- Commits em português, no imperativo.
EOF
  cat > pyproject.toml <<'EOF'
[project]
name = "viga-ficticia"
version = "0.4.0"
requires-python = ">=3.12"

[project.optional-dependencies]
test = ["pytest"]
EOF
  : > src/viga/__init__.py
  cat > src/viga/flecha.py <<'EOF'
"""Verificação de flecha (programa fictício)."""

# Limite de flecha total: L/250, conforme NF-200:2019, item 9.2 (ver docs/normas/NF-200-item-9.md).
LIMITE_FLECHA = 250

# Coeficiente de fluência: 2,0 (igual ao do programa Laje).
COEF_FLUENCIA = 2.0


def flecha_limite(vao_mm: float) -> float:
    return vao_mm / LIMITE_FLECHA


def flecha_total(flecha_imediata_mm: float) -> float:
    return flecha_imediata_mm * (1 + COEF_FLUENCIA)


def verifica(vao_mm: float, flecha_imediata_mm: float) -> bool:
    """True quando a flecha total é aceitável."""
    return flecha_total(flecha_imediata_mm) < flecha_limite(vao_mm)
EOF
  cat > docs/normas/NF-200-item-9.md <<'EOF'
# NF-200:2019 (norma fictícia) — trecho do item 9, transcrito para uso interno

**9.2 Flecha total.** A flecha total de vigas, considerados os efeitos diferidos, é aceitável quando

    δ_total ≤ L / 250

em que L é o vão teórico.

**9.3 Elementos que suportam alvenaria.** Para vigas que suportam paredes de alvenaria, o limite passa a ser L / 500.
EOF
  cat > docs/CRITERIOS.md <<'EOF'
# Critérios de cálculo (fictício)

- Flecha total: NF-200:2019, item 9.2.
- Fluência: coeficiente único aplicado sobre a flecha imediata.
EOF
  cat > docs/VALIDACAO.md <<'EOF'
# Casos validados (fictício)

| Caso | Vão (mm) | Flecha imediata (mm) | Flecha total (mm) | Limite (mm) | Resultado |
|---|---|---|---|---|---|
| V-01 | 5000 | 5,0 | 15,0 | 20,0 | aceitável |
| V-02 | 5000 | 8,0 | 24,0 | 20,0 | não aceitável |
EOF
  printf '# Decisões (fictício)\n\n- D01: flecha total conforme NF-200:2019, item 9.2.\n' > docs/DECISOES.md
  cat > tests/test_flecha.py <<'EOF'
from viga.flecha import flecha_limite, flecha_total


def test_limite():
    assert flecha_limite(5000) == 20.0


def test_total():
    assert flecha_total(5.0) == 15.0
EOF
  cat > tests/test_referencia.py <<'EOF'
"""Teste de referência conferido à mão. NÃO ALTERAR."""
from viga.flecha import verifica


def test_v01():
    assert verifica(5000, 5.0) is True


def test_v02():
    assert verifica(5000, 8.0) is False
EOF
  git init -q -b master && g add -A && g commit -qm "Versão inicial (fictícia)"
  git remote add origin https://github.com/usuario-ficticio/viga-ficticia.git
  git update-ref refs/remotes/origin/master HEAD
  excluir_claude
  db_repo usuario-ficticio/viga-ficticia false "" master true ADMIN true false
  git rev-parse HEAD > "$DB/sha/usuario-ficticio__viga-ficticia__master"
  cat > "$DB/issues/usuario-ficticio__viga-ficticia" <<'EOF'
  #12 [CLOSED] Mostrar a flecha limite no relatório  {enhancement}
  #9 [CLOSED] Corrigir unidade da flecha imediata na tela de entrada  {bug}
EOF
  echo "bug, documentation, enhancement" > "$DB/labels/usuario-ficticio__viga-ficticia"
  echo "$R"
  ;;

loja)
  R="$DEST/loja"; rm -rf "$R"; mkdir -p "$R/loja-api/src" "$R/loja-app/src" "$R/notas"
  echo "anotações soltas, sem git" > "$R/notas/leia.txt"
  cd "$R/loja-api"
  printf '# loja-api (fictício)\n\nAPI da loja. Calcula o total do carrinho.\n' > README.md
  printf '# Agentes (fictício)\n\n- Python 3.12. Testes: `python -m pytest -q`.\n' > AGENTS.md
  cat > src/carrinho.py <<'EOF'
def total_do_carrinho(itens, frete):
    """Total a pagar: soma dos itens mais o frete."""
    return sum(i["preco"] * i["qtd"] for i in itens) + frete
EOF
  git init -q -b main && g add -A && g commit -qm "Versão inicial (fictícia)"
  git remote add origin https://github.com/usuario-ficticio/loja-api.git
  git update-ref refs/remotes/origin/main HEAD; excluir_claude
  cd "$R/loja-app"
  printf '# loja-app (fictício)\n\nInterface da loja. Mostra o total do carrinho.\n' > README.md
  printf '# Agentes (fictício)\n\n- Node 20. Testes: `npm test`.\n' > AGENTS.md
  cat > src/carrinho.js <<'EOF'
// Mostra o total. A API devolve `total` e `frete`; somamos o frete para exibir.
function totalExibido(resposta) { return resposta.total + resposta.frete; }
module.exports = { totalExibido };
EOF
  git init -q -b main && g add -A && g commit -qm "Versão inicial (fictícia)"
  git remote add origin https://github.com/usuario-ficticio/loja-app.git
  git update-ref refs/remotes/origin/main HEAD; excluir_claude
  db_repo usuario-ficticio/loja-api false "" main true ADMIN true false
  db_repo usuario-ficticio/loja-app false "" main true ADMIN true false
  echo "$R"
  ;;

vazio)
  R="$DEST/sem-repo"; rm -rf "$R"; mkdir -p "$R"
  echo "FAKE_GH_AUTH=none" > "$DEST/gh-env"
  echo "$R"
  ;;

*) echo "tipo desconhecido: $TIPO" >&2; exit 2 ;;
esac
