# Capacidade, esforço e delegação

Você não sabe quem vai executar a issue, em que ferramenta, nem com que modelo. Por isso a issue traz uma **recomendação em palavras** e funciona mesmo que ninguém a siga.

## Escreva para o executor mais fraco que pode pegar a issue

Na prática:

- Nenhuma ferramenta presumida: subagentes, busca na internet, MCP, um sistema operacional específico. O que for exigido vai em "Ambiente necessário".
- Condições de parada explícitas em "Pare e pergunte se". Um modelo mais fraco não deduz quando parar.
- Um resultado principal por issue. Se há dois, divida.
- Comandos literais, caminhos exatos, nomes de função. Nada de "o teste apropriado".
- Sem jargão desta skill no corpo: nada de códigos de perfil, nomes de arquivo daqui ou "o model-map".

## Perfis

Use o perfil para decidir o que escrever. No corpo da issue vai só o texto da coluna da direita, adaptado.

| Perfil | Quando | Texto para "Capacidade recomendada" |
|---|---|---|
| Leve | Mudança mecânica em 1–2 arquivos, critério óbvio (texto, constante, configuração) | "Mudança mecânica: um modelo pequeno e rápido basta. Se a validação falhar uma vez ou surgir ambiguidade, troque por um modelo intermediário." |
| Padrão | Bug com reprodução conhecida; funcionalidade pequena ou média em um módulo | "Tarefa de um módulo, com teste novo: um modelo intermediário com esforço padrão basta. Se falhar duas vezes pela mesma causa, ou se a mudança passar de um módulo, use um modelo mais capaz com esforço alto." |
| Complexo | Ambiguidade técnica, vários módulos, concorrência, migração de dados ou de API, cálculo normativo | "Mudança que cruza módulos ou mexe em dados ou em cálculo: use o modelo mais capaz que você tiver, com esforço alto, e escreva o plano antes de editar. Peça revisão de outra sessão ou de uma pessoa antes de entregar." |
| Fronteira | Tarefa crítica ou longa, ou perfil complexo que já falhou | "Tarefa crítica: modelo mais capaz disponível, esforço máximo, plano por escrito e revisão humana do plano e do resultado antes do merge." |

Regra geral: recomende o perfil mais baixo que atende com confiabilidade.

Feche sempre com: "Se você não puder escolher modelo ou esforço, siga com o que tem e diga isso no relatório."

Em P, a capacidade não aparece: a forma curta de "Como executar" basta.

## Nomes de modelo: só como exemplo datado

Nomes mudam e cada usuário tem os seus. Se ajudar, acrescente uma linha depois do texto do perfil, tirada de [`model-map.yaml`](model-map.yaml):

> Exemplos em 2026-11: Claude Code `sonnet`; Codex `gpt-6.1-sol`.

- Sempre com mês e ano, sempre como exemplo, nunca como exigência.
- Os nomes ficam só no `model-map.yaml`. Não os repita em exemplos nem em outros arquivos desta skill.
- Antes de citar, confira `verified_on` no arquivo. Se estiver velho, omita a linha.

## Delegação e paralelismo

- **Padrão: sequencial, um agente.**
- Se o repositório tiver fluxo próprio de agentes (skills, comandos, especificações, papéis descritos nas instruções), **ele prevalece**: aponte para ele em "Como executar" e não prescreva papéis.
- Recomende um revisor separado, que tente refutar cada critério de aceite, quando houver risco de regressão, dados ou cálculo. O revisor existe para tentar quebrar, não para aprovar.
- Recomende um explorador somente leitura quando a issue tiver itens `[a localizar]`.
- Paralelize só quando houver ao menos duas subtarefas de leitura, ou de escrita em conjuntos de arquivos disjuntos declarados na issue, e o ganho compensar o custo: cada subagente gasta os próprios tokens e os mesmos limites de uso.
- Em épico, o paralelismo é entre sub-issues; a tabela da mãe diz quais podem correr juntas e por quê.
- Escrita paralela no mesmo módulo: não recomende.

Toda recomendação de delegação vem com a alternativa para quem não tem subagentes (ver `como-executar.md`). O que muda entre Claude Code e Codex está em `platforms.md`.

## Como fica na issue

````markdown
### Capacidade recomendada
Tarefa de um módulo, com teste novo: um modelo intermediário com esforço padrão basta. Se falhar duas vezes pela mesma causa, ou se a mudança passar de um módulo, use um modelo mais capaz com esforço alto. Recomendado pedir a outra sessão que tente refutar CA1–CA3. Se você não puder escolher modelo ou esforço, siga com o que tem e diga isso no relatório.
Exemplos em 2026-11: Claude Code `sonnet`; Codex `gpt-6.1-sol`.
````
