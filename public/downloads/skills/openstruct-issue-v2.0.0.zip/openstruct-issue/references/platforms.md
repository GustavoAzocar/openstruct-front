# Claude Code e Codex: o que muda na issue

Só o que está documentado (verificado em 2026-11-11; fontes em `VERIFICATION-NOTES.md`). Não presuma equivalência: um recurso de uma plataforma não implica recurso igual na outra. A issue é escrita para servir às duas.

## O que cada executor carrega sozinho

| Arquivo do repositório | Claude Code | Codex |
|---|---|---|
| `CLAUDE.md` (raiz e subpastas), `.claude/CLAUDE.md` | sim | não |
| `.claude/rules/*.md` (regras com `paths` só para os arquivos correspondentes) | sim | não |
| `AGENTS.md` (raiz e subpastas) | não; só se um `CLAUDE.md` o importar com `@AGENTS.md` | sim |
| `README.md`, `CONTRIBUTING.md` | não | não |

Consequência: em "Como executar", liste nominalmente os arquivos de instrução que existem. Um repositório só com `CLAUDE.md` deixa o Codex sem instruções; um só com `AGENTS.md` deixa o Claude Code sem elas.

## Subagentes

**Claude Code**
- Definidos em `.claude/agents/*.md` (projeto) ou `~/.claude/agents/` (usuário), com `model`, `effort` e `isolation: worktree` opcionais.
- `isolation: worktree` cria o worktree **a partir do branch padrão, não do HEAD da sessão**. Se o trabalho estiver num branch de feature, o subagente isolado não vê as mudanças dele.
- Consomem os mesmos limites de uso da conversa principal.

**Codex**
- Nos clientes locais, **só delega quando pedido diretamente** ou quando o `AGENTS.md` ou uma skill aplicável instrui. Recomendação de subagente tem de vir com todas as letras ("use um subagente somente leitura para…").
- Agentes customizados em `.codex/agents/*.toml` ou `~/.codex/agents/`; herdam sandbox e política de aprovação do pai.
- A documentação recomenda começar por tarefas de leitura e ter cuidado com escrita em paralelo.

## O que isso muda na issue

| Situação | O que escrever |
|---|---|
| Sempre | Lista nominal dos arquivos de instrução em "Como executar" |
| Recomenda subagente | Pedido explícito, com a alternativa para quem não tem subagentes |
| Recomenda isolamento em worktree e a base não é o branch padrão | Avisar que o worktree parte do branch padrão |
| Validação depende de sistema operacional ou programa | Dizer em "Ambiente necessário"; não presumir que o executor está no mesmo sistema de quem escreveu |
| Repositório com fluxo próprio de agentes (`.agents/`, `.claude/skills/`, `.codex/`, `.spec/`) | Apontar para o fluxo do repositório; não prescrever papéis |
