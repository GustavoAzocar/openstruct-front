# Cálculo, critérios e normas: material adicional

A regra de ouro, a tabela de origem e a lista de quando pedir confirmação estão no `SKILL.md` e valem sempre. Este arquivo detalha como escrever o requisito de cálculo depois que as dúvidas foram perguntadas.

## 1. Onde procurar antes de perguntar

O script lista documentos de decisão, de validação e PDFs com nome de norma. Leia o que existir, nesta ordem:

1. Instruções do repositório (`AGENTS.md`, `CLAUDE.md`): costumam dizer qual norma e edição valem e qual é o processo (registrar decisão antes de codar, conferência assinada, teste de referência que nunca é regenerado).
2. Documentos de decisão e de critérios (`docs/DECISIONS.md`, `docs/CRITERIOS-…`, ADRs).
3. Documentos de validação e conferência (`docs/VALIDACAO…`, `CONFERENCIA.md`): trazem casos já validados.
4. Texto da norma versionado no repositório.

O que você achar ali é `[verificado em <caminho>, item …]`. Ainda é pergunta: edição da norma quando o documento não a declara, divergência entre dois documentos, e tudo o que só existir em comentário de código.

## 2. Transcrição de fórmula

- Extração de texto de PDF troca símbolos, expoentes e operadores. Fórmula que você transcreveu de PDF é devolvida ao usuário para conferência, lado a lado com o item e a página, antes de virar `[obrigatório]`.
- Atenção ao operador exato da desigualdade (`<` × `≤`), ao lado em que fica o coeficiente e à unidade de cada termo. Se a fonte for ambígua, pergunte.
- Se as instruções do repositório disserem como ler fórmulas (por exemplo, pela imagem da página), siga-as.

## 3. Como escrever o requisito

Seção "Fórmulas, regras e fontes" do template, sem deixar escolha ao executor:

- Tabela de fontes: cada regra ou valor com a fonte primária e a situação (`confirmado pelo usuário`, `[verificado em <caminho>]`, `[hipótese] a confirmar`).
- Fórmulas completas em bloco de código, com símbolos, unidades e o que já existe × o que muda.
- Tabela de decisão ou pseudocódigo para regras com condições, incluindo a fronteira (o que acontece exatamente no limite).
- Arredondamento: em que etapa, para quantas casas, com que regra. Não arredonde valores intermediários se a fonte não mandar.
- Separador decimal: escreva os números como o código os lê (`1.25`), e diga isso; no texto corrido em português pode ir `1,25`.
- Padrão de cada opção nova e a garantia de que os resultados atuais não mudam, quando for o caso.
- O que a norma cobre e esta issue não: vai em "Fora do escopo", para o executor não completar a norma por conta própria.

## 4. Exemplo numérico de referência

O exemplo vira teste. Ele só prova algo se não tiver sido calculado pela mesma leitura da fórmula que será implementada. Use a primeira origem disponível e declare qual foi:

| Ordem | Origem | Como marcar |
|---|---|---|
| 1 | Caso já validado no repositório (documento de validação, teste de referência) | `[verificado em <caminho>]` |
| 2 | Exemplo resolvido da própria fonte (norma, livro) | fonte com página; confirmado pelo usuário |
| 3 | Cálculo do usuário (planilha, memória de cálculo) | "fornecido pelo usuário" |
| 4 | Cálculo de quem escreveu a issue | "calculado pelo autor da issue a partir das fórmulas acima: confere a implementação, não a fórmula" |

- Se só houver a origem 4, pergunte antes ao usuário se ele tem um caso conhecido. Sem resposta, use a 4 com o rótulo e anexe o script num bloco recolhível, para ser auditável.
- Calcule fora do projeto: script temporário fora do repositório, nunca commitado.
- Traga entradas, valores intermediários e resultado, com tolerância absoluta ou relativa e o motivo dela.
- Quando a mudança não deve alterar resultados existentes, peça também um teste de caracterização: o executor registra os resultados atuais antes de editar e mostra que continuam iguais.

## 5. Obrigações do repositório

Se as instruções exigirem registro de decisão, conferência normativa assinada, atualização de documento de validação ou travas de release, isso entra em "Entrega esperada" como `[obrigatório]`, com a fonte. A issue não cria atalhos para esses processos.

## 6. Comparação entre programas ou resultados

Se a demanda nasceu de uma diferença entre dois programas ou dois resultados, reconstitua a causa antes de afirmar que um está errado: as entradas eram iguais? as unidades? a edição da norma? Se não conseguir reconstituir, é `[hipótese]`, e a pergunta ao usuário é qual resultado ele considera correto e por qual fonte.

## 7. Publicação e direitos

- Em repositório público, cite norma, edição e item; não reproduza trecho de norma paga.
- Código, comentário ou documento de repositório privado não vai para issue em repositório público sem o usuário autorizar.
- Fórmula ou trecho portado de projeto com outra licença: pergunte antes.

## 8. O que o executor recebe

No bloco "Como executar" (ver `como-executar.md`): implementar o que está confirmado; conferir só fonte que esteja no repositório ou na issue; nunca confirmar valor, item ou edição de memória ou por busca na internet; parar em `[hipótese]` ou divergência; reproduzir o exemplo numérico pelo código do projeto.
