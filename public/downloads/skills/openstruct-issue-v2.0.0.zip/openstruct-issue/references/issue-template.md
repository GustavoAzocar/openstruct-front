# Template da issue

Um único layout, igual no rascunho e na publicação. O topo é para a pessoa que lê; o bloco recolhível no fim é para o agente que vai executar. O executor não tem esta skill, esta conversa nem a máquina de quem escreveu: tudo de que ele precisa está no corpo.

Entregue cada issue num bloco de quatro crases (` ````markdown `), começando por `# <título>`. Na publicação, essa primeira linha vira o `--title` e sai do corpo.

Os rótulos em **negrito** e os títulos de seção abaixo são literais: `scripts/lint-issue.sh` confere por eles.

## Marcadores

| Marcador | Quando usar |
|---|---|
| `[verificado]` | Você leu o arquivo ou viu a issue nesta sessão. Cite onde: `[verificado em AGENTS.md §4]`. Comando copiado das instruções e não executado: `[verificado em <arquivo>, não executado]`. |
| `[hipótese]` | Inferência ainda não confirmada. Diga o que a confirmaria. |
| `[a localizar]` | Existe com certeza, mas você não achou onde. Nunca chute um caminho. |
| `[obrigatório]` | Requisito que o executor não pode mudar. |
| `[sugestão]` | Abordagem recomendada, que o executor pode trocar se justificar. |

- A primeira menção de cada caminho, comando ou API leva marcador na mesma linha. Arquivo a criar: `[sugestão]` (nome livre) ou `[obrigatório]` (nome exigido).
- Nunca escreva número de linha que você não viu. Prefira nome de função, classe ou teste.
- Caminhos sempre relativos à raiz do repositório e escritos como o `git ls-files` imprime (maiúsculas e minúsculas importam em Linux). Nunca caminho absoluto.
- Comandos copiados literalmente das instruções do repositório, com a fonte. Não "normalize" (`.\.venv\Scripts\python.exe -m pytest -q` não vira `pytest`).
- O que o usuário afirmou e você não pôde conferir: "informado pelo usuário". O que ele confirmou a seu pedido: "confirmado pelo usuário".

## Matriz de seções

O = obrigatória · C = quando se aplica · — = omitir

| Seção | P | M | G-mãe | G-filha |
|---|---|---|---|---|
| Título, na convenção do destino | O | O | O | O |
| Faixa de bloqueio (só se `RASCUNHO BLOQUEADO`) | C | C | C | C |
| **Resultado esperado:** e **Tipo:** | O | O | O | O |
| Problema e impacto | O (1–2 frases) | O | O | C (link para a mãe) |
| Comportamento atual × esperado | — | O | C | O |
| Evidências e referências | — | O | C | C |
| Reprodução e ambiente | — | O se bug | — | O se bug |
| Fórmulas, regras e fontes | — | O se cálculo | C | O se cálculo |
| Escopo e **Fora do escopo** | O (só fora) | O | O | O |
| Requisitos, restrições e contratos a preservar | — | O | O | O |
| Arquivos e componentes relevantes | — | O | C | O |
| Solução: obrigatório × sugestão | — | O | C | O |
| Critérios de aceite (`- [ ]`) | O | O | O | O |
| Plano de validação | O (1 linha) | O | O | O |
| **Ambiente necessário** | O (1 linha) | O | O | O |
| **Pare e pergunte se** | O (1 linha) | O | O | O |
| Dependências, decisões e **Suposições adotadas:** | — | O | O | O |
| Entrega esperada | — | O | O | O |
| Bloco "Para o agente que for executar" | O (curto) | O | O (ordem das filhas) | O |

## Template M

````markdown
# <prefixo do repositório, se houver> <Verbo> <resultado verificável>

**Resultado esperado:** <uma frase verificável>
**Tipo:** <correção | melhoria | nova funcionalidade | cálculo | documentação>

_Marcadores: [verificado] foi conferido no repositório; [hipótese] ainda não; [a localizar] existe, mas não foi achado; [obrigatório] não pode mudar; [sugestão] pode._

## Problema e impacto
<Quem é afetado, o que acontece, por que importa.>

## Comportamento atual × esperado
| Atual | Esperado |
|---|---|
| … [verificado em `caminho`, função `nome`] | … [obrigatório] |

## Evidências e referências
- <log, trecho de documento, issue relacionada com link>

## Reprodução e ambiente
1. …

## Fórmulas, regras e fontes
| Regra ou valor | Fonte primária (norma, edição, item; livro, edição, página; arquivo do repositório) | Situação |
|---|---|---|
| … | … | confirmado pelo usuário / [verificado em `docs/…`] / [hipótese] a confirmar |

Fórmulas, com símbolos e unidades; o que já existe × o que muda:
```
<fórmula completa>
```
Regra de decisão:
| Condição | Resultado |
|---|---|

Exemplo numérico de referência (origem: <caso validado do repositório | exemplo da fonte | cálculo do usuário | cálculo de quem escreveu a issue>):
| Entradas | Resultado esperado | Tolerância |
|---|---|---|

Padrão de cada opção nova: … Os resultados atuais não mudam quando: …

## Escopo
**Dentro:** …
**Fora do escopo:** …

## Requisitos, restrições e contratos a preservar
- [obrigatório] <API pública, formato de dados, compatibilidade com quem já usa, regra das instruções do repositório>

## Arquivos e componentes relevantes
| Caminho | Marcador | Motivo |
|---|---|---|
| `src/…` | [verificado] | <por que olhar aqui> |

## Solução
**Obrigatório:** …
**Sugestão:** … [sugestão]

## Critérios de aceite
- [ ] CA1 <comportamento observável>
- [ ] CA2 …

## Plano de validação
| Critério | Checagem | Tipo |
|---|---|---|
| CA1 | `<comando>` [verificado em `AGENTS.md`, não executado] | automática / manual |

## Ambiente necessário
<Sistema operacional, programas, versões, acessos e dados exigidos pela validação, com a fonte. Ex.: "Windows com a venv do projeto [verificado em AGENTS.md §4]".> Quem não tiver esse ambiente relata o critério como não validado.

## Pare e pergunte se
- <condição concreta desta issue em que o executor não deve decidir sozinho>
- a issue divergir do código de um jeito que mude o resultado esperado;
- for preciso mudar algo listado em "Requisitos, restrições e contratos a preservar".

## Dependências, decisões pendentes e bloqueios
- Depende de: …
- Decisão pendente: … (quem decide)
- Suposições adotadas: <cada uma com "reverter se …"; escreva "nenhuma" se não houver>

## Entrega esperada
<PR para o branch `…` de `dono/repo`, com código, testes novos para os critérios e o que as instruções do repositório exigirem: registro de decisão, versão, conferência normativa.>

<details>
<summary>Para o agente que for executar</summary>

**Controle:** Status: PRONTA · Tamanho: M · Cálculo/norma: não
**Verificação:** Lido em `dono/repo@branch` `abc1234` (AAAA-MM-DD). <O que foi lido; o que não foi executado.>

### Como executar
<passos numerados, preenchidos para esta issue>

### Capacidade recomendada
<em palavras, sem código de perfil nem nome de modelo como exigência>

</details>
````

O texto de "Como executar" vem de `como-executar.md`; o de "Capacidade recomendada", de `model-policy.md`. Nenhum nome de arquivo desta skill aparece na issue.

## Template P

````markdown
# <prefixo, se houver> <Verbo> <resultado>

**Resultado esperado:** <uma frase> [obrigatório]
**Tipo:** <…>

**Problema:** <1–2 frases; onde está, com marcador>
**Fora do escopo:** <1 linha>

- [ ] CA1 …
- [ ] CA2 …

**Validação:** `<comando ou checagem manual>` [verificado em <arquivo>, não executado]
**Ambiente necessário:** <1 linha>
**Pare e pergunte se:** <1 linha>

<details>
<summary>Para o agente que for executar</summary>

**Controle:** Status: PRONTA · Tamanho: P · Cálculo/norma: não
**Verificação:** Lido em `dono/repo@branch` `abc1234` (AAAA-MM-DD).

**Como executar:** <forma curta, 4 a 6 linhas>

</details>
````

A issue P inteira fica em cerca de 300 palavras, contando o bloco do agente. Uma linha para cada rótulo; nada de justificar o óbvio.

## Template G-mãe

````markdown
# <prefixo, se houver> <Verbo> <resultado geral>

**Resultado esperado:** <uma frase>
**Tipo:** <…>

## Problema e impacto
## Escopo
**Dentro:** …
**Fora do escopo:** …
## Requisitos, restrições e contratos a preservar
## Plano de sub-issues
| Ordem | Sub-issue | Resultado verificável | Depende de | Arquivos | Pode correr junto com |
|---|---|---|---|---|---|
| 1 | <título ou link> | … | — | `src/store/**` | — |

## Critérios de aceite
- [ ] Todas as sub-issues fechadas
- [ ] <critério de integração observável>
## Plano de validação
## Ambiente necessário
## Pare e pergunte se
## Dependências, decisões pendentes e bloqueios
- Suposições adotadas: …
## Entrega esperada

<details>
<summary>Para o agente que for executar</summary>

**Controle:** Status: PRONTA · Tamanho: G (issue-mãe) · Cálculo/norma: não
**Verificação:** Lido em `dono/repo@branch` `abc1234` (AAAA-MM-DD).

### Como executar
Não implemente esta issue diretamente. Execute as sub-issues na ordem da tabela; cada uma traz as próprias instruções.

</details>
````

- G-filha usa o template M. No topo, `Pai: <link>` e `Bloqueada por: <link>` só quando o `gh` não tiver `--parent` e `--blocked-by`.
- Sub-issue em outro repositório: use a URL completa. A divisão entre repositórios é confirmada com o usuário antes de redigir.
- Paralelismo só entre filhas com conjuntos de arquivos disjuntos, declarados na tabela.

## Status e bloqueio

Só dois valores: `PRONTA` e `RASCUNHO BLOQUEADO`. Issue-mãe se reconhece por `Tamanho: G (issue-mãe)`; ela também pode estar bloqueada.

Quando bloqueada, logo abaixo do título:

````markdown
> **RASCUNHO BLOQUEADO: não atribuir a agente.**
> **Falta para ficar PRONTA:**
> 1. …
````

E o bloco final traz só o controle (`Status: RASCUNHO BLOQUEADO`) e a frase "Não execute: a issue está bloqueada." Sem "Como executar". O que ainda não se sabe é escrito como "(a definir)".

Bloqueio é só o que impede definir o resultado ou os critérios. Fork atrasado, `gh` sem autenticação e issues relacionadas não pesquisadas são avisos.

**Todo bloco de issue que você entregar usa este layout e passa no verificador**, mesmo quando é parcial, bloqueado ou sem acesso ao repositório. Não existe "rascunho em formato livre": se ainda não dá para preencher o layout bloqueado, entregue só as perguntas.

## Sem acesso ao repositório

Sem clone e sem `gh`, a issue é sempre `RASCUNHO BLOQUEADO`: falta verificar o repositório. Ela traz a seção "Não verificado" logo depois de **Tipo:**, no lugar da linha de verificação:

````markdown
# Não cortar a última linha da tabela na exportação em PDF

> **RASCUNHO BLOQUEADO: não atribuir a agente.**
> **Falta para ficar PRONTA:**
> 1. Ler o repositório: onde o PDF é montado e qual é o comando de validação.
> 2. Pesquisar issues duplicadas.

**Resultado esperado:** o PDF exportado traz todas as linhas da tabela, inclusive a última [obrigatório]
**Tipo:** correção

## Não verificado
- Estrutura do repositório, caminhos e comandos de validação: não foi possível ler o repositório.
- Issues relacionadas: não pesquisadas.

## Problema e impacto
No PDF exportado, a última linha da tabela não aparece (informado pelo usuário).

## Escopo
**Dentro:** montagem da tabela na exportação em PDF.
**Fora do escopo:** outros formatos de exportação; aparência do PDF.

## Arquivos e componentes relevantes
| Caminho | Marcador | Motivo |
|---|---|---|
| ponto em que a tabela é paginada para o PDF | [a localizar] | onde a correção entra |

## Critérios de aceite
- [ ] CA1 Uma tabela com N linhas gera um PDF com as N linhas.
- [ ] CA2 Tabela que ocupa mais de uma página continua completa.

<details>
<summary>Para o agente que for executar</summary>

**Controle:** Status: RASCUNHO BLOQUEADO · Tamanho: M · Cálculo/norma: não

Não execute: a issue está bloqueada.

</details>
````

Nesse modo, caminhos e comandos só aparecem como `[a localizar]` ou `[hipótese]`; o que o usuário contou é "informado pelo usuário"; nada é `[verificado]`.

## Template do próprio repositório

Se o destino tiver template (o script lista os locais e os da API, com o prefixo de título), ele prevalece:

- Use o prefixo de título do template (`[Recurso] `, `[Cálculo] `) e a convenção das issues recentes do destino.
- Preencha as seções do template, na ordem e no idioma dele, com o conteúdo desta skill:

| Seção do repositório (exemplos) | Recebe |
|---|---|
| Descrição, Describe the bug | Problema e impacto; Comportamento atual × esperado |
| Passos, To Reproduce | Reprodução |
| Esperado, Expected behavior | Resultado esperado |
| Logs, Screenshots | Evidências |
| Ambiente, Environment | Reprodução e ambiente |
| Solução proposta, Proposed solution | Solução |
| Critérios de aceite | Critérios de aceite; Plano de validação |
| Contexto adicional | Escopo; Requisitos; Arquivos; Dependências |

- O que for obrigatório na matriz e não couber vai numa seção "Contexto adicional", antes do bloco do agente.
- O bloco "Para o agente que for executar" entra no fim, recolhido, também em repositório de terceiro.
- **Caixas de atestação do template** ("li o guia", "tenho autorização para compartilhar") ficam desmarcadas: quem atesta é o usuário. Avise-o na resposta.
- Formulário (`.yml`): os campos viram as seções do corpo, na mesma ordem.
