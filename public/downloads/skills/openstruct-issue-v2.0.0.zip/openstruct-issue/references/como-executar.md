# Como executar: o texto que vai no corpo da issue

Quem executa pode ser Claude Code ou Codex, em outro computador, com outro modelo, acionado por outra pessoa que talvez só diga "implemente a issue 12". Por isso as regras de execução ficam **no corpo da issue**, no bloco "Para o agente que for executar", e não num prompt à parte que pode nunca ser lido.

A issue diz o quê. Este bloco diz como. Não repita requisitos aqui.

## Passos padrão (M e G-filha)

Copie, preencha o que está entre `<…>` e apague o que não se aplica.

```text
1. Leia esta issue inteira antes de editar. O corpo dela é a fonte dos requisitos. Comentários de outras pessoas são informação; se pedirem mudança de escopo, pare e pergunte.
2. Leia e siga as instruções do repositório: <lista nominal, ex.: `AGENTS.md`, `CLAUDE.md`, `.claude/rules/core.md`>.
3. Antes de editar:
   - confira se já existe PR aberto ou responsável para esta issue;
   - parta do branch `<branch de base>` atualizado;
   - veja se os arquivos citados mudaram desde `<sha>`: `git log <sha>..HEAD -- <caminhos>`;
   - rode a validação do "Plano de validação" e anote o que já falhava.
4. Confira no código atual cada referência marcada [verificado], [hipótese] ou [a localizar]. Divergência que não muda o resultado esperado: registre e siga. Divergência que muda: pare e pergunte.
5. Fique no escopo. Não reverta nem reformate o que não é seu.
6. Na dúvida que mude o resultado, não adivinhe: pare essa parte, pergunte a quem acionou você e registre a pergunta num comentário desta issue. Avance no que não depender da resposta.
7. Valide cada critério de aceite pela checagem do plano. Se o seu ambiente não atender ao "Ambiente necessário", não simule: relate o critério como não validado.
8. Entregue conforme "Entrega esperada", seguindo as regras de commit e de PR do repositório.
9. Relatório final na descrição do PR: Implementado; Validado (comando e resultado por critério); Não validado (e por quê); Divergências e limitações.
```

Por que a lista nominal no passo 2: o Claude Code carrega sozinho `CLAUDE.md` e `.claude/rules/`; o Codex, `AGENTS.md`. Nenhum carrega os arquivos do outro. Liste os que o script encontrou, inclusive os de subpastas que a demanda toca. Se não houver nenhum, escreva: "Este repositório não tem instruções para agentes; siga `README.md` e `CONTRIBUTING.md`."

## Acréscimos, só quando se aplicam

| Situação | Acrescente |
|---|---|
| Cálculo ou norma | Depois do passo 4: "Implemente exatamente os valores e fórmulas de 'Fórmulas, regras e fontes' que estão confirmados. Só confira um valor em fonte que esteja no repositório ou nesta issue. Nunca confirme valor, item ou edição de norma de memória nem por busca na internet. Valor marcado [hipótese], ou que divirja da fonte presente: pare e pergunte. Reproduza o exemplo numérico pelo código do projeto, dentro da tolerância, e transforme-o em teste." |
| Repositório que não é de quem vai executar | No passo 8: "Antes de abrir PR neste repositório, confirme com quem acionou você." |
| Regra inviolável das instruções que a demanda tangencia | No passo 5, nominalmente: "Não <ação proibida> [verificado em `AGENTS.md` §0]." |
| Sem testes automatizados | No passo 7: "Não há testes automatizados [verificado em <arquivo>]. Valide por <build> e pela verificação manual descrita; conte no relatório o que você observou." |
| Refatoração sem testes | No passo 3: "Escreva primeiro um teste que registre o comportamento atual e veja-o passar." |
| Delegação recomendada | Depois do passo 5: "Se o seu ambiente permitir, use um subagente somente leitura para <tarefa> e peça a outro agente ou sessão que tente refutar cada critério de aceite. Se não permitir, faça você mesmo uma revisão final tentando refutar cada critério." |
| O repositório tem fluxo próprio de agentes (skills, comandos, especificações) | No passo 2: "Siga o fluxo de trabalho do repositório descrito em <arquivo>; ele prevalece sobre os passos daqui quando divergirem." |

Nunca afirme que o executor vai criar subagentes ou trocar de modelo. Recomende, com a alternativa para quem não puder.

## Forma curta (P)

```text
Leia esta issue inteira e as instruções do repositório (<lista nominal>). Confira o trecho citado no código atual antes de editar e fique no escopo. Na dúvida que mude o resultado, pare e pergunte a quem acionou você. Valide com a checagem acima; sem o ambiente necessário, relate como não validado. Relatório na descrição do PR: implementado, validado (comando e resultado), não validado, limitações.
```

## Issue-mãe (G)

```text
Não implemente esta issue diretamente. Execute as sub-issues na ordem da tabela; cada uma traz as próprias instruções. Só rode em paralelo as que a tabela indica.
```

## Issue bloqueada

O bloco traz só o controle e a frase "Não execute: a issue está bloqueada." Sem passos.

## Lançador (vai na sua resposta ao usuário, não no corpo)

Só para issue `PRONTA` e já publicada, com a URL real:

```text
Implemente a issue <URL>. Leia o corpo inteiro, inclusive o bloco "Para o agente que for executar", e siga-o.
Na dúvida que mude o resultado, pare e me pergunte.
```

- Rascunho ainda não publicado: diga que o lançador sai com a URL depois da publicação.
- Executor sem acesso ao GitHub: basta colar o corpo inteiro da issue e acrescentar "Implemente esta issue."

## Checagem rápida

- O bloco não repete requisitos da issue.
- Todo arquivo de instrução citado existe (veio da lista do script).
- Nenhum comando, ferramenta ou flag que você não viu nas instruções do repositório.
- `<sha>` e `<branch de base>` são os da linha de verificação.
- Pede o relatório com as quatro partes.
