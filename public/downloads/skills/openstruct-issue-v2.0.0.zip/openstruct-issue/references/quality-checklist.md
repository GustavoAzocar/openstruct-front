# Checklist de qualidade: o teste do agente frio

Aplique antes de entregar ou publicar. Imagine um agente que nunca viu esta conversa, em outro computador, com um modelo mais fraco que o seu, recebendo só a issue e o repositório.

Primeiro rode o verificador (`scripts/lint-issue.sh`, do jeito descrito em "Como rodar os scripts" no `SKILL.md`). Ele cobre os rótulos, os restos de preenchimento, as referências a esta skill e os caminhos absolutos:

```text
lint-issue.sh --blocos <arquivo com a resposta>     rascunho: confere cada bloco de quatro crases
lint-issue.sh --publicar <arquivo do corpo>         antes de publicar: o corpo, sem a linha do título
```

O arquivo é temporário e fica fora do repositório. Se não der para gravar arquivo, confira à mão os rótulos da matriz do template.

Depois responda o que o verificador não enxerga. Todo "não" é corrigido antes da entrega, ou vira item de bloqueio.

## Base

| # | Pergunta | Se falhar |
|---|---|---|
| 1 | O agente começa só com a issue e o repositório? | Traga para a issue o que ficou na conversa: decisões, nomes, exemplos, respostas do usuário |
| 2 | Há um único resultado principal verificável? | Reescreva em uma frase; dois resultados independentes viram duas issues |
| 3 | Cada critério de aceite é observável e tem checagem no plano de validação? | Troque "funciona bem" por comportamento observável |
| 4 | A primeira menção de todo caminho, comando ou API tem marcador, e nada foi inventado? | Marque; se inventou, remova |
| 5 | Obrigatório e sugestão estão separados? | Marque cada item da solução |
| 6 | O tamanho do texto combina com o tamanho da demanda? | P em cerca de 300 palavras; G dividida |
| 7 | Não há segredos, dados pessoais nem nome de cliente? | Remova ou use `<redigido>` |

## Projeto

| # | Pergunta | Se falhar |
|---|---|---|
| 8 | Os repositórios (leitura, origin, fork e pai, destino, branch de base) foram confirmados pelo usuário? | Pergunte; sem resposta possível, marque "não confirmado" e não publique |
| 9 | Comandos de validação copiados literalmente das instruções, com a fonte, e "Ambiente necessário" preenchido? | Copie do arquivo; se não está documentado, `[a localizar]` e pergunta |
| 10 | Regras invioláveis e processos obrigatórios das instruções aparecem na issue, e nada os contraria? | Cite-os em "Requisitos" e "Entrega esperada"; conflito vira pergunta |
| 11 | "Como executar" lista nominalmente os arquivos de instrução que existem? | Use a lista do script |
| 12 | A linha de verificação bate com o branch de base, ou o desvio está explicado? | Leia pelo branch padrão do destino, ou explique |
| 13 | Título, idioma e seções seguem a convenção e o template do destino? | Ajuste; caixas de atestação ficam desmarcadas |

## Dúvidas

| # | Pergunta | Se falhar |
|---|---|---|
| 14 | Alguma suposição adotada mudaria título, critério, escopo, destino ou valor se fosse outra? | Não é suposição: vira pergunta, e a issue fica `RASCUNHO BLOQUEADO` até a resposta |
| 15 | "Pare e pergunte se" traz ao menos uma condição específica desta issue? | Escreva-a; a lista genérica não basta |
| 16 | Respostas do usuário estão registradas como "confirmado pelo usuário"? | Registre |

## Cálculo, critério ou norma

| # | Pergunta | Se falhar |
|---|---|---|
| 17 | Cada fórmula, coeficiente e limite tem origem classificada, e nada de fonte secundária (outro programa, relatório, comentário, memória) virou `[obrigatório]`? | Rebaixe para `[hipótese]` e pergunte a fonte primária |
| 18 | Fórmula transcrita de PDF foi devolvida ao usuário para conferência? | Mostre a transcrição com item e página |
| 19 | Há fórmulas completas com unidades, regra de decisão com a fronteira, arredondamento, padrão de cada opção e o que não muda? | Escreva; sem isso o executor adivinha |
| 20 | O exemplo numérico declara a origem, e não é só um cálculo seu sem rótulo? | Procure caso validado, pergunte por um, ou rotule e anexe o script |
| 21 | O executor é instruído a implementar o confirmado e a nunca confirmar de memória? | Acrescente o texto de cálculo em "Como executar" |
| 22 | As obrigações normativas do repositório estão em "Entrega esperada"? | Acrescente, com a fonte |

## Publicação

| # | Pergunta | Se falhar |
|---|---|---|
| 23 | O usuário pediu explicitamente para criar no GitHub? | Entregue só o texto |
| 24 | Destino que não é do usuário: houve confirmação com título, destino e visibilidade? | Peça antes de criar |
| 25 | Destino público: nada de repositório privado nem trecho de norma paga? | Remova ou pergunte |
| 26 | Labels existem e você tem permissão? Se não, o usuário foi avisado? | Publique sem elas e avise |
| 27 | Depois de criar: issue relida, links reais nas relações, lançador entregue? | Releia e corrija |

## O que informar

Uma linha: "Verificador: sem erros. Checklist: sem pendências." ou a lista dos itens pendentes e por quê. Não informe contagem de itens.
