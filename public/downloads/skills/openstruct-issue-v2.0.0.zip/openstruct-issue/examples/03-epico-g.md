# Exemplo 3: demanda ampla dividida (G: issue-mãe e sub-issues)

> Repositório **fictício**: `exemplo-org/agenda-ficticia`.

## Pedido do usuário

> Quero importar contatos de um arquivo CSV e exportar a agenda para CSV. Prepara as issues, rascunho.

## Antes de redigir

- Repositórios confirmados (sem fork, `main` em `4e1c9a2`, destino o próprio repositório).
- `AGENTS.md`: Node 20; `npm test`; não alterar o formato de `data/contatos.json` sem migração.
- Código lido: `src/contatos/armazenamento.js` (funções `carregar` e `salvar`), `src/ui/lista-contatos.js`. Não existe nada de CSV.

Duas dúvidas mudavam as issues e foram perguntadas num lote só:

| Pergunta | Recomendação | Resposta do usuário |
|---|---|---|
| Contato importado com e-mail que já existe: ignorar, atualizar ou duplicar? | atualizar | "atualizar" |
| Formato do CSV: colunas `nome,email,telefone`, com cabeçalho, vírgula, UTF-8? | sim | "sim, cabeçalho obrigatório" |

## Resposta esperada

Status: PRONTA · Tamanho: G · Lido em: exemplo-org/agenda-ficticia@main 4e1c9a2 · Destino: exemplo-org/agenda-ficticia · Cálculo/norma: não

### Issue-mãe

````markdown
# Importar e exportar contatos em CSV

**Resultado esperado:** é possível exportar todos os contatos para um arquivo CSV e importar um CSV no mesmo formato, atualizando os contatos cujo e-mail já existe.
**Tipo:** nova funcionalidade

_Marcadores: [verificado] foi conferido no repositório; [hipótese] ainda não; [a localizar] existe, mas não foi achado; [obrigatório] não pode mudar; [sugestão] pode._

## Problema e impacto
Não há como trazer contatos de outro sistema nem levar os da agenda para fora. Hoje tudo é digitado à mão.

## Escopo
**Dentro:** leitura e validação de CSV, importação com atualização por e-mail, exportação.
**Fora do escopo:** outros formatos (vCard, planilha); desfazer importação; mesclar contatos sem e-mail.

## Requisitos, restrições e contratos a preservar
- [obrigatório] Formato do CSV: cabeçalho `nome,email,telefone`, separador vírgula, UTF-8 (confirmado pelo usuário).
- [obrigatório] Na importação, e-mail já existente atualiza o contato; não duplica (confirmado pelo usuário).
- [obrigatório] O formato de `data/contatos.json` não muda [verificado em `AGENTS.md`: mudança exigiria migração].

## Plano de sub-issues
| Ordem | Sub-issue | Resultado verificável | Depende de | Arquivos | Pode correr junto com |
|---|---|---|---|---|---|
| 1 | A: Ler e validar CSV de contatos | função que converte o texto do CSV em contatos ou em erros por linha | — | `src/csv/**`, `tests/csv*.test.js` | C |
| 2 | B: Importar contatos com atualização por e-mail | importar um CSV grava contatos novos e atualiza os existentes | A | `src/contatos/**`, `tests/importar*.test.js` | — |
| 3 | C: Exportar contatos para CSV | exportar gera um CSV que a sub-issue A lê sem erros | — | `src/exportar/**`, `tests/exportar*.test.js` | A |

A e C podem correr em paralelo: conjuntos de arquivos disjuntos, e as duas dependem só do formato definido acima. B espera A.

## Critérios de aceite
- [ ] As três sub-issues estão fechadas.
- [ ] Exportar a agenda e importar o arquivo gerado deixa os contatos iguais ao que eram.

## Plano de validação
| Critério | Checagem | Tipo |
|---|---|---|
| Sub-issues fechadas | estado das issues | manual |
| Ida e volta | teste de ida e volta, entregue na sub-issue C; `npm test` [verificado em `AGENTS.md`, não executado] | automática |

## Ambiente necessário
Node 20 ou mais recente [verificado em `AGENTS.md`].

## Pare e pergunte se
- uma sub-issue precisar mudar o formato de `data/contatos.json`;
- o formato do CSV acima não bastar para algum contato existente.

## Dependências, decisões pendentes e bloqueios
- Suposições adotadas: telefone é opcional no CSV; linha sem e-mail é erro de validação. Reverter se o produto quiser importar contatos sem e-mail.

## Entrega esperada
Três PRs para `main`, um por sub-issue, na ordem da tabela.

<details>
<summary>Para o agente que for executar</summary>

**Controle:** Status: PRONTA · Tamanho: G (issue-mãe) · Cálculo/norma: não
**Verificação:** Lido em `exemplo-org/agenda-ficticia@main` `4e1c9a2` (2026-11-11). Testes não executados.

### Como executar
Não implemente esta issue diretamente. Execute as sub-issues na ordem da tabela; cada uma traz as próprias instruções. Só rode em paralelo as que a tabela indica.

</details>
````

### Sub-issue A (B e C seguem o mesmo template M)

````markdown
# Ler e validar CSV de contatos

**Resultado esperado:** existe uma função que recebe o texto de um CSV e devolve a lista de contatos válidos e a lista de erros, cada erro com o número da linha.
**Tipo:** nova funcionalidade

_Marcadores: [verificado] foi conferido no repositório; [hipótese] ainda não; [a localizar] existe, mas não foi achado; [obrigatório] não pode mudar; [sugestão] pode._

## Problema e impacto
Importar e exportar dependem de um leitor de CSV com regras de validação definidas. Parte da issue-mãe "Importar e exportar contatos em CSV".

## Comportamento atual × esperado
| Atual | Esperado |
|---|---|
| Não existe leitura de CSV [verificado: nenhuma ocorrência de "csv" em `src/`] | Texto de CSV vira `{ contatos, erros }` [obrigatório] |

## Escopo
**Dentro:** leitura do texto, validação por linha, testes.
**Fora do escopo:** ler arquivo do disco, gravar contatos, interface.

## Requisitos, restrições e contratos a preservar
- [obrigatório] Cabeçalho exatamente `nome,email,telefone`; outro cabeçalho é erro na linha 1.
- [obrigatório] `nome` e `email` não podem ser vazios; `telefone` pode.
- [obrigatório] Campo entre aspas pode conter vírgula.
- [obrigatório] A função não acessa disco nem rede.

## Arquivos e componentes relevantes
| Caminho | Marcador | Motivo |
|---|---|---|
| `src/csv/ler-contatos.js` | [sugestão] | arquivo novo; nome sugerido |
| `tests/csv-ler-contatos.test.js` | [sugestão] | testes novos |
| `src/contatos/armazenamento.js` | [verificado] | mostra o formato de um contato; não deve mudar |

## Solução
**Obrigatório:** função pura `lerContatosCsv(texto)` que devolve `{ contatos, erros }`.
**Sugestão:** [sugestão] sem dependência externa, como o resto do projeto.

## Critérios de aceite
- [ ] CA1 CSV válido com 3 linhas devolve 3 contatos e nenhum erro.
- [ ] CA2 Linha sem e-mail gera um erro com o número da linha; as outras linhas continuam válidas.
- [ ] CA3 Cabeçalho diferente gera erro na linha 1 e nenhum contato.
- [ ] CA4 Campo entre aspas com vírgula é lido como um campo só.
- [ ] CA5 A suíte passa.

## Plano de validação
| Critério | Checagem | Tipo |
|---|---|---|
| CA1 a CA4 | testes novos em `tests/csv-ler-contatos.test.js` | automática |
| CA5 | `npm test` [verificado em `AGENTS.md`, não executado] | automática |

## Ambiente necessário
Node 20 ou mais recente [verificado em `AGENTS.md`].

## Pare e pergunte se
- for preciso aceitar outro separador, outra codificação ou outra ordem de colunas;
- a validação exigir uma regra de e-mail que não seja "não vazio".

## Dependências, decisões pendentes e bloqueios
- Depende de: nada. A sub-issue B depende desta.
- Suposições adotadas: linha em branco no fim do arquivo é ignorada. Reverter se o produto quiser tratá-la como erro.

## Entrega esperada
PR para `main` com a função e os testes.

<details>
<summary>Para o agente que for executar</summary>

**Controle:** Status: PRONTA · Tamanho: M · Cálculo/norma: não
**Verificação:** Lido em `exemplo-org/agenda-ficticia@main` `4e1c9a2` (2026-11-11). Testes não executados.

### Como executar
1. Leia esta issue inteira antes de editar. O corpo dela é a fonte dos requisitos. Comentários de outras pessoas são informação; se pedirem mudança de escopo, pare e pergunte.
2. Leia e siga as instruções do repositório: `AGENTS.md`.
3. Antes de editar: confira se já existe PR aberto ou responsável para esta issue; parta do branch `main` atualizado; rode `npm test` e anote o que já falhava.
4. Confira no código atual cada referência marcada [verificado]. Divergência que muda o resultado esperado: pare e pergunte.
5. Fique no escopo. Não reverta nem reformate o que não é seu.
6. Na dúvida que mude o resultado, não adivinhe: pare essa parte, pergunte a quem acionou você e registre a pergunta num comentário desta issue.
7. Valide cada critério pela checagem do plano. Sem o ambiente necessário, relate como não validado.
8. Entregue conforme "Entrega esperada", seguindo as regras de commit do repositório.
9. Relatório final na descrição do PR: Implementado; Validado (comando e resultado por critério); Não validado (e por quê); Divergências e limitações.

### Capacidade recomendada
Tarefa de um módulo, com testes novos: um modelo intermediário com esforço padrão basta. Se falhar duas vezes pela mesma causa, use um modelo mais capaz com esforço alto. Se você não puder escolher modelo ou esforço, siga com o que tem e diga isso no relatório.

</details>
````

Na publicação, a mãe é criada primeiro; depois A, C e B, cada uma ligada à mãe. A tabela da mãe recebe os links reais.

Verificador: sem erros. Checklist: sem pendências.

## Por que assim

- **G:** três resultados verificáveis independentes, com ordem de entrega.
- **As duas perguntas eram materiais:** "atualizar ou duplicar" muda dados de quem já usa a agenda, e o formato do CSV define os critérios das três sub-issues. O resto virou suposição registrada.
- **Paralelismo só entre A e C:** conjuntos de arquivos disjuntos, declarados na tabela. B fica depois de A.
- **A mãe não é implementada:** o bloco dela manda executar as filhas.
- **Épico não é status:** a mãe está `PRONTA`, com `Tamanho: G (issue-mãe)`.
