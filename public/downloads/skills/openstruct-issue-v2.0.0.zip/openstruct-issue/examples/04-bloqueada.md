# Exemplo 4: informação insuficiente (RASCUNHO BLOQUEADO)

> Repositório **fictício**: `exemplo-org/agenda-ficticia`.

## Pedido do usuário

> A agenda está travando. Abre uma issue pra resolver.

## O que o script e a leitura mostraram

- Repositórios confirmados pelo usuário (sem fork, `main` em `4e1c9a2`, destino o próprio repositório).
- `src/contatos/armazenamento.js` lê e grava `data/contatos.json` inteiro a cada operação. `src/ui/lista-contatos.js` refaz a lista inteira a cada tecla digitada na busca.
- Não há medição de desempenho no repositório: nenhuma ocorrência de "bench", "perf" ou "timing".

Nada disso diz o que trava. São pistas.

## Com usuário para responder: só perguntas

Status: RASCUNHO BLOQUEADO · Tamanho: M · Lido em: exemplo-org/agenda-ficticia@main 4e1c9a2 · Destino: exemplo-org/agenda-ficticia · Cálculo/norma: não

**Falta para ficar PRONTA:**

1. **O que trava?** Abrir a agenda, salvar um contato, digitar na busca ou outra ação. Sem isso não há resultado para verificar.
2. **Quanto tempo leva hoje, e quanto seria aceitável?** Um número aproximado basta. Recomendo fixar a meta em segundos, para virar critério de aceite.
3. **Com quantos contatos acontece?** Dezenas, milhares. As duas pistas que achei só pesam com muitos contatos.

Sem issue neste turno: ela seria reescrita depois das respostas.

## Sem usuário para responder (execução em lote): perguntas no topo e rascunho mínimo

As mesmas três perguntas, seguidas de:

````markdown
# Reduzir o tempo da ação que trava a agenda (a definir)

> **RASCUNHO BLOQUEADO: não atribuir a agente.**
> **Falta para ficar PRONTA:**
> 1. Qual ação trava.
> 2. Tempo atual e tempo aceitável.
> 3. Volume de contatos em que acontece.

**Resultado esperado:** (a definir, depois das respostas)
**Tipo:** melhoria

## Evidências e referências
- [hipótese] `src/contatos/armazenamento.js` lê e grava o arquivo inteiro a cada operação; o custo cresce com o número de contatos. Confirmaria: medir com 10 mil contatos.
- [hipótese] `src/ui/lista-contatos.js` refaz a lista a cada tecla da busca. Confirmaria: medir a digitação com volume alto.
- Não há medição de desempenho no repositório [verificado: busca por "bench", "perf" e "timing"].

<details>
<summary>Para o agente que for executar</summary>

**Controle:** Status: RASCUNHO BLOQUEADO · Tamanho: M · Cálculo/norma: não
**Verificação:** Lido em `exemplo-org/agenda-ficticia@main` `4e1c9a2` (2026-11-11).

Não execute: a issue está bloqueada.

</details>
````

## Por que assim

- **Três perguntas, todas mudam a issue:** título, critério e escopo dependem delas. Nada sobre preferência de implementação.
- **As pistas do código viram `[hipótese]`,** com o que as confirmaria. Nenhuma é apresentada como causa.
- **Bloqueada não tem "Como executar":** entregar passos para uma issue bloqueada convidaria um agente a adivinhar.
- **O que não se sabe é "(a definir)",** não um espaço entre sinais de menor e maior.
