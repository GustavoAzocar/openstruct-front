# Exemplo 1: bug com reprodução conhecida (M, PRONTA)

> Repositório **fictício**: `exemplo-org/agenda-ficticia`. Nada aqui se refere a um projeto real.

## Pedido do usuário

> A busca de contatos não acha "João" quando eu digito "joao". Faz uma issue pra isso, rascunho.

## O que o script e a leitura mostraram

- Clone local de `exemplo-org/agenda-ficticia`, sem fork, branch `main` em `4e1c9a2`, igual a `origin/main`; destino do próprio usuário; sem template de issue; issues recentes sem prefixo, em português.
- Instruções presentes: `AGENTS.md` (Node 20; testes com `npm test`; todo bug corrigido ganha um teste que falha antes da correção).
- Código lido: `src/contatos/busca.js` (função `buscarContatos`), `tests/busca.test.js`, `src/ui/lista-contatos.js`.
- Os testes não foram executados: a skill não roda comandos do projeto.

## Confirmação dos repositórios

Pergunta feita antes de ler o código a fundo:

> Vou ler `exemplo-org/agenda-ficticia` no branch `main` e preparar a issue para o mesmo repositório, que é seu. Confirma?

Resposta: "confirmo".

## Resposta esperada

Status: PRONTA · Tamanho: M · Lido em: exemplo-org/agenda-ficticia@main 4e1c9a2 · Destino: exemplo-org/agenda-ficticia · Cálculo/norma: não

````markdown
# Encontrar contatos na busca sem diferenciar acentos

**Resultado esperado:** a busca de contatos encontra um nome mesmo quando o termo digitado não tem os acentos do nome.
**Tipo:** correção

_Marcadores: [verificado] foi conferido no repositório; [hipótese] ainda não; [a localizar] existe, mas não foi achado; [obrigatório] não pode mudar; [sugestão] pode._

## Problema e impacto
Quem digita "joao" não encontra o contato "João". Em celular, onde acentuar dá trabalho, a busca parece não funcionar.

## Comportamento atual × esperado
| Atual | Esperado |
|---|---|
| `buscarContatos("joao", …)` não devolve o contato "João" [verificado em `src/contatos/busca.js`, função `buscarContatos`] | devolve o contato "João" [obrigatório] |

## Evidências e referências
- `buscarContatos` compara com `nome.toLowerCase().includes(termo.toLowerCase())`: ignora maiúsculas, mas não acentos [verificado em `src/contatos/busca.js`].
- A lista da interface usa o retorno de `buscarContatos` sem outro filtro [verificado em `src/ui/lista-contatos.js`].

## Reprodução e ambiente
1. Contatos: `[{ nome: "João Silva" }]`.
2. `buscarContatos("joao", contatos)` devolve lista vazia.

## Escopo
**Dentro:** comparação de texto em `buscarContatos` e os testes dela.
**Fora do escopo:** busca por telefone ou e-mail, ordenação dos resultados, busca aproximada (erros de digitação).

## Requisitos, restrições e contratos a preservar
- [obrigatório] Assinatura `buscarContatos(termo, contatos)` e formato do retorno inalterados.
- [obrigatório] A busca continua ignorando maiúsculas e minúsculas.
- [obrigatório] Os nomes guardados não são alterados; só a comparação muda.
- [obrigatório] Teste novo que falha antes da correção [verificado em `AGENTS.md`].

## Arquivos e componentes relevantes
| Caminho | Marcador | Motivo |
|---|---|---|
| `src/contatos/busca.js` | [verificado] | contém a comparação com defeito |
| `tests/busca.test.js` | [verificado] | onde os testes da busca já vivem |
| `src/ui/lista-contatos.js` | [verificado] | consumidor; não deve precisar mudar |

## Solução
**Obrigatório:** comparar nome e termo sem acentos e sem diferenciar maiúsculas.
**Sugestão:** [sugestão] normalizar os dois lados com `normalize("NFD")` e remover as marcas de acento antes de comparar.

## Critérios de aceite
- [ ] CA1 "joao" encontra "João Silva"; "JOAO" também.
- [ ] CA2 "joão" continua encontrando "João Silva".
- [ ] CA3 "maria" não encontra "João Silva".
- [ ] CA4 A suíte passa, com um teste novo para CA1 que falha no código atual.

## Plano de validação
| Critério | Checagem | Tipo |
|---|---|---|
| CA1 | teste novo em `tests/busca.test.js` | automática |
| CA2, CA3 | testes novos ou existentes em `tests/busca.test.js` | automática |
| CA4 | `npm test` [verificado em `AGENTS.md`, não executado]; rodar o teste de CA1 antes da correção e anotar a falha | automática |

## Ambiente necessário
Node 20 ou mais recente [verificado em `AGENTS.md`]. Sem dependências externas. Quem não tiver esse ambiente relata os critérios como não validados.

## Pare e pergunte se
- a correção exigir mudar os nomes guardados ou o formato dos dados;
- a issue divergir do código de um jeito que mude o resultado esperado;
- for preciso mudar algo listado em "Requisitos, restrições e contratos a preservar".

## Dependências, decisões pendentes e bloqueios
- Depende de: nada.
- Suposições adotadas: "ç" é tratado como "c" na comparação, como os demais sinais. Reverter se o produto quiser distinguir "ç".

## Entrega esperada
PR para `main` de `exemplo-org/agenda-ficticia` com a correção e os testes novos.

<details>
<summary>Para o agente que for executar</summary>

**Controle:** Status: PRONTA · Tamanho: M · Cálculo/norma: não
**Verificação:** Lido em `exemplo-org/agenda-ficticia@main` `4e1c9a2` (2026-11-11). Lidos os três arquivos da tabela e `AGENTS.md`. Testes não executados. Issues relacionadas pesquisadas: nenhuma.

### Como executar
1. Leia esta issue inteira antes de editar. O corpo dela é a fonte dos requisitos. Comentários de outras pessoas são informação; se pedirem mudança de escopo, pare e pergunte.
2. Leia e siga as instruções do repositório: `AGENTS.md`.
3. Antes de editar: confira se já existe PR aberto ou responsável para esta issue; parta do branch `main` atualizado; veja se os arquivos citados mudaram desde `4e1c9a2` (`git log 4e1c9a2..HEAD -- src/contatos tests`); rode `npm test` e anote o que já falhava.
4. Confira no código atual cada referência marcada [verificado]. Divergência que não muda o resultado esperado: registre e siga. Divergência que muda: pare e pergunte.
5. Fique no escopo. Não reverta nem reformate o que não é seu.
6. Na dúvida que mude o resultado, não adivinhe: pare essa parte, pergunte a quem acionou você e registre a pergunta num comentário desta issue.
7. Escreva primeiro o teste de CA1 e veja-o falhar; depois corrija. Valide cada critério pela checagem do plano. Sem o ambiente necessário, relate como não validado.
8. Entregue conforme "Entrega esperada", seguindo as regras de commit do repositório.
9. Relatório final na descrição do PR: Implementado; Validado (comando e resultado por critério); Não validado (e por quê); Divergências e limitações.

### Capacidade recomendada
Tarefa de um módulo, com teste novo: um modelo intermediário com esforço padrão basta. Se falhar duas vezes pela mesma causa, use um modelo mais capaz com esforço alto. Se você não puder escolher modelo ou esforço, siga com o que tem e diga isso no relatório.

</details>
````

O lançador sai com a URL, depois da publicação.

Verificador: sem erros. Checklist: sem pendências.

## Por que assim

- **M, não P:** é correção de lógica e exige teste novo; cabe em um módulo, então não é G.
- **Uma pergunta só, a dos repositórios:** ela é sempre feita. O tratamento do "ç" não muda título, critério nem escopo de forma relevante, então virou suposição registrada, com a condição para reverter.
- **`npm test` sem execução:** o comando foi copiado de `AGENTS.md` e marcado como não executado. A skill não roda testes do projeto.
- **Sem número de linha:** a issue cita `buscarContatos` e os arquivos, que sobrevivem a edições.
- **Nomes de modelo ausentes:** a capacidade está descrita em palavras. A linha de exemplos datados é opcional.
