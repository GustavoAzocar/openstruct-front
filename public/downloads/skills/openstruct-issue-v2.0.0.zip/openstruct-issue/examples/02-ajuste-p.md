# Exemplo 2: ajuste simples (P)

> Repositório **fictício**: `exemplo-org/agenda-ficticia`.

## Pedido do usuário

> Na agenda (é o meu repositório exemplo-org/agenda-ficticia, base main, pode usar o clone daqui), aumenta de 20 para 50 os contatos por página. Só o rascunho.

## O que o script e a leitura mostraram

- O usuário já declarou repositório, destino e base: a pergunta dos repositórios é dispensada. O script confirma: sem fork, `main` em `4e1c9a2`, igual a `origin/main`.
- `AGENTS.md`: Node 20; testes com `npm test`.
- `src/config.js` define `CONTATOS_POR_PAGINA = 20`; a busca pelo nome acha um único uso, em `src/ui/lista-contatos.js`. Nenhum teste cita o valor.

## Resposta esperada

Status: PRONTA · Tamanho: P · Lido em: exemplo-org/agenda-ficticia@main 4e1c9a2 · Destino: exemplo-org/agenda-ficticia · Cálculo/norma: não

````markdown
# Mostrar 50 contatos por página

**Resultado esperado:** a lista de contatos mostra até 50 contatos por página [obrigatório]
**Tipo:** melhoria

**Problema:** a lista mostra 20 contatos por página, o que obriga a paginar muito. O valor está em `src/config.js`, constante `CONTATOS_POR_PAGINA` [verificado], usada só em `src/ui/lista-contatos.js` [verificado].
**Fora do escopo:** tornar o valor configurável pelo usuário; mudar a ordenação ou a busca.

- [ ] CA1 `CONTATOS_POR_PAGINA` vale 50.
- [ ] CA2 A suíte passa.

**Validação:** `npm test` [verificado em `AGENTS.md`, não executado]
**Ambiente necessário:** Node 20 ou mais recente [verificado em `AGENTS.md`].
**Pare e pergunte se:** o valor 20 aparecer escrito em outro lugar além da constante.

<details>
<summary>Para o agente que for executar</summary>

**Controle:** Status: PRONTA · Tamanho: P · Cálculo/norma: não
**Verificação:** Lido em `exemplo-org/agenda-ficticia@main` `4e1c9a2` (2026-11-11). Testes não executados.

**Como executar:** Leia esta issue inteira e as instruções do repositório (`AGENTS.md`). Confira o trecho citado no código atual antes de editar e fique no escopo. Na dúvida que mude o resultado, pare e pergunte a quem acionou você. Valide com a checagem acima; sem o ambiente necessário, relate como não validado. Relatório na descrição do PR: implementado, validado (comando e resultado), não validado, limitações.

</details>
````

O lançador sai com a URL, depois da publicação.

Verificador: sem erros. Checklist: sem pendências.

## Por que assim

- **P:** uma constante, um arquivo, critério óbvio. Nada de tabela de arquivos, solução ou capacidade recomendada.
- **Nenhuma pergunta:** os repositórios vieram no pedido e não há dúvida que mude o resultado.
- **Uma linha por rótulo.** "Ambiente necessário" e "Pare e pergunte se" existem em toda issue, mas em P cabem numa linha cada.
