# Exemplo 7: cálculo e norma (bloqueada no primeiro turno, PRONTA no segundo)

> Repositório, programa e norma **fictícios**: `exemplo-org/laje-ficticia` e "NF-100". Os números não vêm de norma real.

## Pedido do usuário

> No Laje, o coeficiente de redução da sobrecarga para vão de exatamente 6 m está saindo 0,90. No meu outro programa, o Viga, sai 1,00. Acho que o Laje está errado. Faz a issue.

## O que o script e a leitura mostraram

- Clone local de `exemplo-org/laje-ficticia`, sem fork, branch `master` em `b7d20f1`, igual a `origin/master`; repositório privado do próprio usuário.
- Instruções presentes: só `CLAUDE.md` (não há `AGENTS.md`). Ele diz: testes com `python -m pytest -q`; toda mudança de critério de cálculo registra uma decisão em `docs/DECISOES.md` antes do código.
- `docs/CRITERIOS.md`: "redução da sobrecarga conforme NF-100, Tabela 4", sem edição e sem os valores.
- `docs/VALIDACAO.md`: caso V-03, vão de 7,5 m, coeficiente 0,90, conferido. Nenhum caso nos limites.
- `src/laje/reducao.py`, função `coef_reducao(vao_m)`: devolve 1,00 abaixo de 6 m, 0,90 a partir de 6 m e 0,85 a partir de 9 m (comparações com `>=`).

## Primeiro turno: só perguntas

Os repositórios foram confirmados pela ferramenta de perguntas ("Vou ler `exemplo-org/laje-ficticia` em `master` e preparar a issue para o mesmo repositório. Confirma?" — "confirmo"). As dúvidas de cálculo vão em texto, porque a resposta é um item de norma:

Status: RASCUNHO BLOQUEADO · Tamanho: M · Lido em: exemplo-org/laje-ficticia@master b7d20f1 · Destino: exemplo-org/laje-ficticia · Cálculo/norma: sim

**Falta para ficar PRONTA:**

1. **Fonte e edição.** `docs/CRITERIOS.md` cita "NF-100, Tabela 4" sem edição e sem os valores. Qual edição vale, em que item está a tabela e quais são as faixas e os coeficientes?
2. **Fronteira.** A tabela dá 1,00 para vão "até 6 m" ou "abaixo de 6 m"? O código usa "a partir de 6 m" para 0,90; o Viga dá 1,00 em 6 m. O Viga é pista, não fonte: preciso do texto da linha da tabela. O mesmo vale para o limite de 9 m.
3. **Quem já usa.** Corrigir o limite muda o resultado de projetos salvos com vão de exatamente 6 m (e talvez 9 m). Posso exigir a mudança sem opção de compatibilidade? Recomendo que sim, com registro na decisão.
4. **Caso de referência.** Você tem um caso conferido à mão em um dos limites? O documento de validação só cobre 7,5 m.

Nesse turno não há issue: ela seria reescrita depois das respostas.

## Resposta do usuário

> NF-100:2024, item 7.3.2, Tabela 4: vão ≤ 6 m, 1,00; 6 m < vão ≤ 9 m, 0,90; vão > 9 m, 0,85. O Laje está errado nos dois limites. Pode mudar sem opção. Caso à mão eu não tenho; use a tabela.

## Segundo turno: resposta esperada

Status: PRONTA · Tamanho: M · Lido em: exemplo-org/laje-ficticia@master b7d20f1 · Destino: exemplo-org/laje-ficticia · Cálculo/norma: sim

````markdown
# Corrigir os limites de vão do coeficiente de redução da sobrecarga

**Resultado esperado:** `coef_reducao` devolve 1,00 para vão de até 6 m inclusive, 0,90 acima de 6 m até 9 m inclusive e 0,85 acima de 9 m.
**Tipo:** cálculo

_Marcadores: [verificado] foi conferido no repositório; [hipótese] ainda não; [a localizar] existe, mas não foi achado; [obrigatório] não pode mudar; [sugestão] pode._

## Problema e impacto
Nos vãos de exatamente 6 m e 9 m o programa aplica o coeficiente da faixa seguinte e reduz a sobrecarga mais do que a norma permite, contra a segurança.

## Comportamento atual × esperado
| Vão | Atual | Esperado |
|---|---|---|
| 6,00 m | 0,90 [verificado em `src/laje/reducao.py`, função `coef_reducao`] | 1,00 [obrigatório] |
| 9,00 m | 0,85 [verificado, mesma função] | 0,90 [obrigatório] |
| demais | conforme a tabela abaixo | sem mudança [obrigatório] |

## Evidências e referências
- `coef_reducao` compara com "maior ou igual" nos dois limites [verificado em `src/laje/reducao.py`].
- `docs/CRITERIOS.md` cita "NF-100, Tabela 4" sem edição e sem valores [verificado].
- Outro programa do mesmo autor devolve 1,00 para 6 m (informado pelo usuário). É pista, não fonte.

## Fórmulas, regras e fontes
| Regra ou valor | Fonte primária | Situação |
|---|---|---|
| Faixas e coeficientes de redução | NF-100:2024, item 7.3.2, Tabela 4 | confirmado pelo usuário em 2026-11-11 |

Regra de decisão, com as fronteiras (`vao_m` em metros; coeficiente adimensional):
```
vao_m <= 6.0            -> 1.00
6.0 < vao_m <= 9.0      -> 0.90
vao_m > 9.0             -> 0.85
```
O que já existe × o que muda: os três coeficientes já existem; mudam só as duas comparações de limite. Sem arredondamento: o coeficiente é um dos três valores exatos. Os números acima estão escritos como o código os lê, com ponto decimal.

Exemplo numérico de referência:
| Entrada `vao_m` | Resultado esperado | Tolerância | Origem |
|---|---|---|---|
| 7.5 | 0.90 | exata | caso V-03 [verificado em `docs/VALIDACAO.md`] |
| 6.0 | 1.00 | exata | linha da Tabela 4, confirmada pelo usuário |
| 6.01 | 0.90 | exata | idem |
| 9.0 | 0.90 | exata | idem |
| 9.01 | 0.85 | exata | idem |

Os casos de fronteira saem diretamente da tabela confirmada; nenhum foi calculado por quem escreveu a issue.

Opções novas: nenhuma. A mudança vale para todos os projetos, sem opção de compatibilidade (confirmado pelo usuário). Os resultados atuais não mudam para vãos diferentes de 6,00 m e 9,00 m.

## Escopo
**Dentro:** as duas comparações de limite em `coef_reducao`, os testes e os documentos de critério.
**Fora do escopo:** qualquer outro item da NF-100; interpolação entre faixas; mudança dos três coeficientes; outros programas.

## Requisitos, restrições e contratos a preservar
- [obrigatório] Assinatura e unidade de `coef_reducao(vao_m)` inalteradas.
- [obrigatório] O caso V-03 continua dando 0,90.
- [obrigatório] Registrar a decisão em `docs/DECISOES.md` antes de alterar o código [verificado em `CLAUDE.md`].

## Arquivos e componentes relevantes
| Caminho | Marcador | Motivo |
|---|---|---|
| `src/laje/reducao.py` | [verificado] | contém `coef_reducao` |
| `tests/test_reducao.py` | [a localizar] | testes da função; confirmar o nome do arquivo |
| `docs/CRITERIOS.md` | [verificado] | cita a tabela sem edição nem valores |
| `docs/VALIDACAO.md` | [verificado] | caso V-03 |
| `docs/DECISOES.md` | [verificado em `CLAUDE.md`] | onde a decisão é registrada |

## Solução
**Obrigatório:** implementar a regra de decisão acima, exatamente com essas fronteiras.
**Sugestão:** [sugestão] acrescentar a `docs/VALIDACAO.md` os quatro casos de fronteira do exemplo numérico.

## Critérios de aceite
- [ ] CA1 `coef_reducao` devolve os cinco resultados do exemplo numérico.
- [ ] CA2 Existe um teste para cada linha do exemplo; os de 6.0 e 9.0 falham no código atual.
- [ ] CA3 `docs/CRITERIOS.md` passa a trazer a edição, o item e as três faixas.
- [ ] CA4 A decisão está registrada em `docs/DECISOES.md`.
- [ ] CA5 A suíte inteira passa.

## Plano de validação
| Critério | Checagem | Tipo |
|---|---|---|
| CA1, CA2 | testes novos; rodar os de 6.0 e 9.0 antes da correção e anotar a falha | automática |
| CA3, CA4 | leitura dos dois documentos no PR | manual |
| CA5 | `python -m pytest -q` [verificado em `CLAUDE.md`, não executado] | automática |

## Ambiente necessário
Python com as dependências do projeto instaladas, conforme `CLAUDE.md` [verificado]. Quem não tiver esse ambiente relata os critérios como não validados.

## Pare e pergunte se
- algum valor ou fronteira do código, dos documentos ou dos testes existentes divergir da regra de decisão desta issue;
- outro ponto do programa depender do comportamento atual em 6 m ou 9 m;
- for preciso mexer em outro item da norma para concluir.

## Dependências, decisões pendentes e bloqueios
- Depende de: nada.
- Suposições adotadas: nenhuma.

## Entrega esperada
PR para `master` de `exemplo-org/laje-ficticia` com: registro em `docs/DECISOES.md`, feito antes do código [obrigatório]; a correção; os testes; `docs/CRITERIOS.md` atualizado.

<details>
<summary>Para o agente que for executar</summary>

**Controle:** Status: PRONTA · Tamanho: M · Cálculo/norma: sim
**Verificação:** Lido em `exemplo-org/laje-ficticia@master` `b7d20f1` (2026-11-11). Lidos `CLAUDE.md`, `src/laje/reducao.py`, `docs/CRITERIOS.md` e `docs/VALIDACAO.md`. Testes não executados. O texto da norma não está no repositório: os valores foram confirmados pelo usuário.

### Como executar
1. Leia esta issue inteira antes de editar. O corpo dela é a fonte dos requisitos. Comentários de outras pessoas são informação; se pedirem mudança de escopo, pare e pergunte.
2. Leia e siga as instruções do repositório: `CLAUDE.md`. Este repositório não tem `AGENTS.md`.
3. Antes de editar: confira se já existe PR aberto ou responsável para esta issue; parta do branch `master` atualizado; veja se os arquivos citados mudaram desde `b7d20f1` (`git log b7d20f1..HEAD -- src/laje docs tests`); rode `python -m pytest -q` e anote o que já falhava.
4. Confira no código atual cada referência marcada [verificado] ou [a localizar]. Divergência que muda o resultado esperado: pare e pergunte.
5. Implemente exatamente os valores e as fronteiras de "Fórmulas, regras e fontes". Não confira a norma de memória nem por busca na internet: os valores já foram confirmados e a norma não está no repositório. Se algo no repositório divergir deles, pare e pergunte.
6. Registre a decisão em `docs/DECISOES.md` antes de alterar o código. Fique no escopo. Não reverta nem reformate o que não é seu.
7. Na dúvida que mude o resultado, não adivinhe: pare essa parte, pergunte a quem acionou você e registre a pergunta num comentário desta issue.
8. Reproduza o exemplo numérico pelo código do projeto e transforme cada linha em teste. Valide cada critério pela checagem do plano. Sem o ambiente necessário, relate como não validado.
9. Entregue conforme "Entrega esperada". Relatório final na descrição do PR: Implementado; Validado (comando e resultado por critério); Não validado (e por quê); Divergências e limitações.

### Capacidade recomendada
A mudança é pequena, mas é cálculo normativo: use um modelo intermediário ou superior com esforço alto e peça a outra sessão, ou a uma pessoa, que confira a regra de decisão contra os testes antes do merge. Se você não puder escolher modelo ou esforço, siga com o que tem e diga isso no relatório.

</details>
````

O lançador sai com a URL, depois da publicação.

Verificador: sem erros. Checklist: sem pendências.

## Por que assim

- **O outro programa não virou requisito.** Ele deu a pista de que havia um problema; a regra veio da tabela, com edição e item informados pelo usuário.
- **A pergunta 2 mudou a issue.** O pedido falava só de 6 m; o texto da tabela mostrou o mesmo defeito em 9 m.
- **Nenhum exemplo numérico foi calculado pela skill.** Um veio do documento de validação do repositório; os de fronteira são as próprias linhas da tabela confirmada.
- **O executor não é mandado "conferir a norma".** Ele não a tem. A instrução é implementar o confirmado e parar se o repositório divergir.
- **`CLAUDE.md` é citado pelo nome.** Um executor Codex não o carregaria sozinho.
- **O processo do repositório foi herdado:** a decisão registrada antes do código está em requisitos, critérios e entrega.
