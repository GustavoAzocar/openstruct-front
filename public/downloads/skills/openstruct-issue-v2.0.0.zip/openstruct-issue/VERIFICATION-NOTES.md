# Notas de verificação

"Conferido" = executado ou lido nesta data, no ambiente indicado. Reconfira antes de confiar: modelos, aliases e flags mudam.

## Versão 2.0.0 — conferido em 2026-11-11

### Ambiente

| Item | Observado |
|---|---|
| Sistema | Windows 11 Pro; PowerShell 7.7.0; Git Bash (o bash que vem com o Git) |
| `git` | 2.52.0.windows.1; `core.autocrlf=true` no git do sistema |
| `gh` | 2.97.0 (2026-07-31), **autenticado** |
| `claude` | Claude Code 2.1.322 |
| `codex` | 0.139.0 instalado; a skill **não** foi instalada nem testada nele |
| Onde foi exercitado | `C:\GNApp`: pasta com 14 repositórios independentes (um fork, um origin de terceiro, um remote com 404, nomes com espaço, `main` e `master`) |

### Conferido por execução

- **`gh repo view` sem argumento, num fork com remote `upstream`, devolve o repositório-base, não o origin.** Reproduzido num fork real; foi a causa de o script 1.1.0 informar "é fork: false". A 2.0.0 usa slug explícito em toda chamada.
- **Campos de `gh repo view --json`** usados pelo script, todos aceitos no 2.97.0: `nameWithOwner`, `isFork`, `parent`, `defaultBranchRef`, `hasIssuesEnabled`, `viewerPermission`, `isPrivate`, `isArchived`, `visibility`, `isInOrganization`, `issueTemplates` (com `name` e `title`; o `title` traz o prefixo de título do template). Em versão que rejeitar um campo, o script repete a consulta com a lista mínima.
- **Leituras pela API**, executadas: `gh api user`, `gh api repos/<slug>/commits/<branch>`, `gh api repos/<slug>/git/trees/<branch>?recursive=1`, `gh api repos/<slug>/contents/<caminho>?ref=<branch>` com `Accept: application/vnd.github.raw`, `gh issue list -R … --json`, `gh label list -R … --json`.
- **`scripts/repo-context.sh`**: 67 checagens em `evals/test-repo-context.sh` (repositórios descartáveis e `gh` falso) e execução nos 14 repositórios reais, com `git status`, HEAD e refs idênticos antes e depois.
- **`scripts/lint-issue.sh`**: 61 checagens em `evals/test-lint-issue.sh`; todos os exemplos passam.
- **PowerShell**: `bash` no PATH do PowerShell resolve para o WSL (`C:\Windows\system32\bash.exe`), que nesta máquina não tem distribuição. O bash do Git é achado a partir de `(Get-Command git).Source`, e os dois scripts rodam por ele, com acentos preservados.
- **Sessões `claude -p` nesta máquina oferecem só a ferramenta PowerShell** (não a Bash) e não têm `AskUserQuestion`. A avaliação rodou assim.
- **Argumentos acentuados** passados pelo PowerShell 7 a um executável nativo chegam íntegros (testado com título contendo acentos, `—` e `&`).
- **`install.sh`**: ajuda, recusa quando origem e destino são a mesma pasta, cópia só dos arquivos de uso, recusa de sobrescrita sem confirmação. No Git Bash, `ln -s` copia em vez de criar link; por isso a instalação no Windows é sempre cópia.

### Conferido só no `--help` do `gh` 2.97.0 (não executado)

- `gh issue create`: `-R`, `--title`, `--body-file`, `--label`, `--type`, `--parent` (número ou URL), `--blocked-by`, `--blocking`.
- `gh issue edit`: `--body-file`, `--type`, `--parent`, `--remove-parent`, `--add-sub-issue`, `--remove-sub-issue`, `--add-blocked-by`, `--remove-blocked-by`, `--add-blocking`.
- `gh issue comment`: `--body-file`, `--edit-last`.
- `gh issue view --json`: inclui `body`, `comments`, `labels`, `parent`, `subIssues`, `blockedBy`, `blocking`, `issueType`.
- `gh search code --repo`.

### Pendente (não conferido)

- **Publicação real no GitHub.** Nenhuma issue foi criada, editada ou comentada de verdade. A avaliação usa um `gh` falso, que confere a montagem do comando, não o comportamento do GitHub.
- **Comportamento com permissão `READ`**: o que acontece com `--label`, `--type`, `--parent` e `--blocked-by` num repositório de terceiro. A skill omite labels e tipo nesse caso e manda repetir sem o item se a criação falhar.
- **Tipos de issue em organização**: nenhum repositório exercitado pertence a uma organização com tipos definidos.
- **Linux e macOS.** O script foi escrito para bash 3.2 (sem vetores associativos, `mapfile` ou `${x,,}`) e só usa `timeout` quando é o do coreutils, mas **não foi executado fora do Windows**.
- **Sessões com a ferramenta Bash** e com `AskUserQuestion` (sessão interativa): o caminho avaliado foi PowerShell e pergunta em texto.
- **Codex**, como autor de issues com a skill e como executor de uma issue gerada.
- **Upload no claude.ai** e sessões em nuvem.
- **Um executor rodando uma issue gerada**, de qualquer modelo: a avaliação mede a issue produzida, não a execução dela.

## Herdado da versão 1.1.0 — não reconferido na 2.0.0

Lido na documentação em 2026-11-11 por quem escreveu a 1.1.0 (ambiente Linux, `gh` 2.89.0 sem autenticação). A 2.0.0 usa esses fatos só em `references/model-map.yaml` e `references/platforms.md`.

**Padrão Agent Skills** — https://agentskills.io/specification.md
- Frontmatter: `name` (até 64, minúsculas, números e hífens, igual ao nome da pasta), `description` (até 1024), `license`, `compatibility`, `metadata`, `allowed-tools`. A skill usa `name`, `description` e `metadata`.

**Claude Code** — https://code.claude.com/docs/en/skills, `/memory`, `/sub-agents`, `/model-config`, `/best-practices`
- Skills pessoais em `~/.claude/skills/<nome>/`, de projeto em `.claude/skills/<nome>/`. Sessões em nuvem não leem a pasta pessoal.
- Lê `CLAUDE.md`, não `AGENTS.md`; recomenda `CLAUDE.md` com `@AGENTS.md`. Lê `.claude/rules/` recursivamente.
- Subagentes em `.claude/agents/` e `~/.claude/agents/`; `isolation: worktree` parte do **branch padrão, não do HEAD**; consomem os mesmos limites de uso.
- Aliases de modelo: `haiku` → Haiku 5.5, `sonnet` → Sonnet 5.5, `opus` → Opus 5.5, `fable` → **Fable 5.1** segundo a documentação naquela data; o Fable 5.2 (`claude-fable-5-2`) tinha sido anunciado em 2026-11-09. Níveis de esforço `low` a `max`, conforme o modelo.

**Codex** — https://learn.chatgpt.com/docs/models, `/config-file/config-reference`, `/agent-configuration/subagents.md`, `/build-skills`
- Modelos `gpt-6-astra`, `gpt-6.1-sol`, `gpt-6.1-terra`, `gpt-6-luna`; esforço em `model_reasoning_effort`.
- Delega a subagentes quando pedido diretamente ou quando `AGENTS.md` ou uma skill aplicável instrui.
- Skills em `.agents/skills` (repositório) e `$HOME/.agents/skills` (usuário); `~/.codex/skills` não aparece na documentação. Nesta máquina existe `~/.codex/skills` e não existe `~/.agents/skills`.
- Lê `AGENTS.md` na raiz e em subpastas.

**GitHub** — https://github.blog/changelog/2026-06-10-manage-sub-issues-types-and-dependencies-from-github-cli/
- O GitHub CLI 2.94.0 acrescentou `--type`, `--parent`, `--blocked-by` e `--blocking`; tipos dependem da organização.
